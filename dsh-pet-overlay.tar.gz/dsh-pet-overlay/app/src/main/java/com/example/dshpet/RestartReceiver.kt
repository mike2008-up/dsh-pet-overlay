package com.example.dshpet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * 心跳接收器：闹钟每 60 秒叫醒一次，发现服务没了就把它拉起来。
 * 闹钟不依赖进程存活，所以能扛住“划掉后台”。
 */
class RestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = Prefs(context)
        if (prefs.cookie == null) return
        if (!prefs.keepAlive) return
        val start = Intent(context, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_START)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(start)
            else context.startService(start)
        }.onFailure {
            // 系统限制后台启动时，退回普通 startService，等下一次闹钟再试
            runCatching { context.startService(start) }
        }
    }
}
