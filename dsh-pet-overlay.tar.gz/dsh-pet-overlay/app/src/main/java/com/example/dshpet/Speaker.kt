package com.example.dshpet

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** 已安装音色：voice 名 → 展示名。 */
data class VoiceOption(val id: String, val label: String)

/**
 * 系统语音合成。
 *
 * 三件事必须处理，否则会“点了没声音”：
 *  1. TTS 初始化是异步的 —— 就绪前的朗读先排队，不留丢
 *  2. 中文语音包可能没装 —— 逐级回退语言，并回调状态给界面
 *  3. 引擎可能不存在 —— 回调里明确告知
 */
class Speaker(
    context: Context,
    private val prefs: Prefs,
) {

    /** 状态回调：给界面显示用。 */
    var onStatus: ((String) -> Unit)? = null

    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var langNote: String = ""
    private var engineName: String = ""
    private var utteranceId = 0

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                onStatus?.invoke("语音引擎初始化失败（status=$status）")
                return@TextToSpeech
            }
            ready = true
            tuneVoice()
            pending?.let { text ->
                pending = null
                speak(text)
            }
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = onStatus?.invoke("正在朗读…") ?: Unit
            override fun onDone(id: String?) = onStatus?.invoke("朗读结束") ?: Unit
            @Deprecated("旧接口")
            override fun onError(id: String?) = onStatus?.invoke("朗读失败") ?: Unit
            override fun onError(id: String?, errorCode: Int) = onStatus?.invoke("朗读失败（code=$errorCode）") ?: Unit
        })
    }

    /** 逐级尝试中文语音，挑女声；失败时回退到默认语言。 */
    private fun tuneVoice() {
        val tts = engine ?: return
        val choices = listOf(Locale.SIMPLIFIED_CHINESE, Locale.CHINESE, Locale.getDefault())
        var chosen: Locale? = null
        for (locale in choices) {
            val available = runCatching { tts.isLanguageAvailable(locale) }.getOrDefault(-2)
            if (available >= TextToSpeech.LANG_AVAILABLE) {
                chosen = locale
                break
            }
        }
        val ttsInfo = runCatching { tts.defaultEngine }.getOrNull().orEmpty()
        engineName = ttsInfo.ifEmpty { "(默认引擎)" }
        if (chosen == null) {
            langNote = "缺中文语音数据"
            onStatus?.invoke("引擎 $engineName 缺中文语音数据——仍会尝试朗读，可能不准")
            runCatching { tts.language = Locale.getDefault() }
            runCatching { tts.setPitch(prefs.voicePitch) }
            runCatching { tts.setSpeechRate(prefs.voiceRate) }
            return
        }
        langNote = "中文可用"
        runCatching { tts.language = chosen }

        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        val zh = voices.filter { it.locale.language == "zh" }
        val female = zh.firstOrNull { voice ->
            val name = voice.name.lowercase()
            listOf("female", "xiaoxiao", "xiaoyi", "huihui", "lili", "tingting", "meijia").any { name.contains(it) }
        } ?: zh.firstOrNull()
        female?.let { runCatching { tts.voice = it } }

        // 用户选过的音色优先
        val saved = prefs.voiceId
        if (saved.isNotEmpty()) {
            voices.firstOrNull { it.name == saved }?.let { runCatching { tts.voice = it } }
        }
        runCatching { tts.setPitch(prefs.voicePitch) }
        runCatching { tts.setSpeechRate(prefs.voiceRate) }
        onStatus?.invoke("语音就绪（$engineName，$langNote）")
    }

    /** 列出所有中文音色，供界面选择。 */
    fun availableVoices(): List<VoiceOption> {
        val tts = engine ?: return emptyList()
        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        return voices
            .filter { it.locale.language == "zh" }
            .sortedBy { it.name }
            .map { voice ->
                val extra = buildString {
                    if (voice.isNetworkConnectionRequired) append(" · 需联网")
                    if (!voice.isNetworkConnectionRequired) append(" · 离线")
                }
                VoiceOption(voice.name, voice.name + extra)
            }
    }

    /** 选择音色并立即预览。 */
    fun selectVoice(id: String, preview: String? = null) {
        val tts = engine ?: return
        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        voices.firstOrNull { it.name == id }?.let { voice ->
            runCatching { tts.voice = voice }
            prefs.voiceId = id
            runCatching { tts.setPitch(prefs.voicePitch) }
            runCatching { tts.setSpeechRate(prefs.voiceRate) }
            preview?.let { speak(it) }
        }
    }

    fun setPitch(value: Float) {
        prefs.voicePitch = value
        runCatching { engine?.setPitch(value) }
    }

    fun setRate(value: Float) {
        prefs.voiceRate = value
        runCatching { engine?.setSpeechRate(value) }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pending = text
            onStatus?.invoke("语音引擎还没准备好，稍后自动朗读")
            return
        }
        utteranceId += 1
        val mode = runCatching {
            engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dsh-pet-$utteranceId")
        }.getOrNull()
        if (mode == TextToSpeech.ERROR) onStatus?.invoke("朗读失败：引擎拒绝了这段文本")
    }

    fun shutdown() {
        runCatching { engine?.stop() }
        runCatching { engine?.shutdown() }
        engine = null
        ready = false
    }
}
