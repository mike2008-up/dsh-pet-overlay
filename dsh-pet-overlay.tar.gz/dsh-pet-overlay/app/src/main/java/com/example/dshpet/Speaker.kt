package com.example.dshpet

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * 系统语音合成：把文字念出来，不需要任何录音资源。
 * TTS 引擎初始化是异步的，就绪之前的调用会被丢弃（不阻塞界面）。
 */
class Speaker(context: Context) {

    private var engine: TextToSpeech? = null
    private var ready = false

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tuneVoice()
        }
    }

    /** 朝“少女音”调：优先中文女声，音调抬高、语速略快。 */
    private fun tuneVoice() {
        val tts = engine ?: return
        runCatching { tts.language = Locale.SIMPLIFIED_CHINESE }
        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        val zh = voices.filter { it.locale.language == "zh" }
        val preferred = zh.firstOrNull { voice ->
            val name = voice.name.lowercase()
            name.contains("female") || name.contains("xiaoxiao") || name.contains("xiaoyi") ||
                name.contains("huihui") || name.contains("lili") || name.contains("tingting")
        } ?: zh.firstOrNull { it.locale.country == "CN" } ?: zh.firstOrNull()
        preferred?.let { runCatching { tts.voice = it } }
        runCatching { tts.setPitch(1.35f) }
        runCatching { tts.setSpeechRate(1.05f) }
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        runCatching { engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dsh-pet") }
    }

    fun stop() {
        runCatching { engine?.stop() }
    }

    fun shutdown() {
        runCatching { engine?.stop() }
        runCatching { engine?.shutdown() }
        engine = null
        ready = false
    }
}
