package com.example.dshpet

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

data class VoiceOption(val id: String, val label: String)

/**
 * 系统语音合成，支持切换引擎与音色。
 *
 * 处理了三种常见坑：
 *  1. 初始化是异步的 —— 朗读先排队
 *  2. 某些引擎的 voices 是空的，但照样能念 —— 不因此报“没装语音包”
 *  3. 一个引擎往往只有一个中文音色 —— 提供引擎切换
 */
class Speaker(
    private val context: Context,
    private val prefs: Prefs,
) {

    var onStatus: ((String) -> Unit)? = null

    private var engine: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var utteranceId = 0
    private var started = false

    private val initListener = TextToSpeech.OnInitListener { status ->
        if (status != TextToSpeech.SUCCESS) {
            onStatus?.invoke("语音引擎初始化失败（status=$status）")
            return@OnInitListener
        }
        ready = true
        tuneVoice()
        pending?.let { text ->
            pending = null
            speak(text)
        }
    }

    /** 首次使用前调用；切换引擎时内部会重建。 */
    fun start() {
        if (started) return
        started = true
        engine = TextToSpeech(context.applicationContext, initListener, prefs.engineName.ifEmpty { null })
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = onStatus?.invoke("正在朗读…") ?: Unit
            override fun onDone(id: String?) = onStatus?.invoke("朗读结束") ?: Unit
            @Deprecated("旧接口")
            override fun onError(id: String?) = onStatus?.invoke("朗读失败") ?: Unit
            override fun onError(id: String?, errorCode: Int) = onStatus?.invoke("朗读失败（code=$errorCode）") ?: Unit
        })
    }

    fun switchEngine(name: String) {
        val tts = engine
        ready = false
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        prefs.engineName = name
        engine = TextToSpeech(context.applicationContext, initListener, name)
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = onStatus?.invoke("正在朗读…") ?: Unit
            override fun onDone(id: String?) = onStatus?.invoke("朗读结束") ?: Unit
            @Deprecated("旧接口")
            override fun onError(id: String?) = onStatus?.invoke("朗读失败") ?: Unit
            override fun onError(id: String?, errorCode: Int) = onStatus?.invoke("朗读失败（code=$errorCode）") ?: Unit
        })
        onStatus?.invoke("已切换到引擎 $name，正在初始化…")
    }

    /** 已安装的语音引擎（包名）。 */
    fun engines(): List<String> =
        runCatching { TextToSpeech.getEngines().toList() }.getOrDefault(emptyList())

    private fun tuneVoice() {
        start()
        val tts = engine ?: return
        val zh = runCatching { tts.isLanguageAvailable(Locale.SIMPLIFIED_CHINESE) }.getOrDefault(-2)
        if (zh >= TextToSpeech.LANG_AVAILABLE) {
            runCatching { tts.language = Locale.SIMPLIFIED_CHINESE }
        } else {
            onStatus?.invoke("当前引擎缺中文数据，仍会尝试朗读")
        }

        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        val saved = prefs.voiceId
        if (saved.isNotEmpty()) {
            voices.firstOrNull { it.name == saved }?.let { runCatching { tts.voice = it } }
        } else {
            val preferred = voices.filter { it.locale.language == "zh" }
                .firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    listOf("female", "xiaoxiao", "xiaoyi", "huihui", "lili", "tingting", "meijia")
                        .any { name.contains(it) }
                }
                ?: voices.firstOrNull { it.locale.language == "zh" }
            preferred?.let { runCatching { tts.voice = it } }
        }
        runCatching { tts.setPitch(prefs.voicePitch) }
        runCatching { tts.setSpeechRate(prefs.voiceRate) }
        onStatus?.invoke("语音就绪（引擎 ${prefs.engineName.ifEmpty { "默认" }}，音色 ${voices.size} 个）")
    }

    /**
     * 可选音色：优先中文，其次全部；引擎完全不暴露音色时返回空。
     */
    fun availableVoices(): List<VoiceOption> {
        val tts = engine ?: return emptyList()
        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        val zh = voices.filter { it.locale.language == "zh" }
        val pool = zh.ifEmpty { voices }
        return pool.sortedBy { it.name }.map { voice ->
            val note = buildString {
                append(if (voice.isNetworkConnectionRequired) " · 需联网" else " · 离线")
                if (voice.locale.language != "zh") append(" · ${voice.locale.language}")
            }
            VoiceOption(voice.name, voice.name + note)
        }
    }

    fun selectVoice(id: String, preview: String? = null) {
        val tts = engine ?: return
        val voices = runCatching { tts.voices?.toList() }.getOrNull().orEmpty()
        voices.firstOrNull { it.name == id }?.let { voice ->
            runCatching { tts.voice = voice }
            prefs.voiceId = id
            runCatching { tts.setPitch(prefs.voicePitch) }
            runCatching { tts.setSpeechRate(prefs.voiceRate) }
            preview?.let { speak(it) }
        }
    }

    fun setPitch(value: Float) {
        prefs.voicePitch = value
        runCatching { engine?.setPitch(value) }
    }

    fun setRate(value: Float) {
        prefs.voiceRate = value
        runCatching { engine?.setSpeechRate(value) }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        start()
        if (!ready) {
            pending = text
            onStatus?.invoke("引擎还没就绪，稍后自动朗读")
            return
        }
        utteranceId += 1
        val result = runCatching {
            engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dsh-pet-$utteranceId")
        }.getOrNull()
        if (result == TextToSpeech.ERROR) onStatus?.invoke("朗读失败：引擎拒绝了这段文本")
    }

    fun shutdown() {
        runCatching { engine?.stop() }
        runCatching { engine?.shutdown() }
        engine = null
        ready = false
        started = false
    }
}
