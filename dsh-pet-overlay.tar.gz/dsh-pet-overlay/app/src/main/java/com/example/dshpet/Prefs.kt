package com.example.dshpet

import android.content.Context

/**
 * 只存三样东西：DSH 基地址、连接用 cookie、上次填的启动地址。
 * 明文 SharedPreferences 就够了，这里没有敏感凭据以外的内容。
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("dsh_pet", Context.MODE_PRIVATE)

    var baseUrl: String
        get() = sp.getString("base_url", "http://127.0.0.1:3080") ?: "http://127.0.0.1:3080"
        set(value) = sp.edit().putString("base_url", value).apply()

    var cookie: String?
        get() = sp.getString("cookie", null)
        set(value) = sp.edit().putString("cookie", value).apply()

    var launchUrl: String
        get() = sp.getString("launch_url", "") ?: ""
        set(value) = sp.edit().putString("launch_url", value).apply()

    /** 选中的 TTS 引擎包名，空表示系统默认。 */
    var engineName: String
        get() = sp.getString("engine_name", "") ?: ""
        set(value) = sp.edit().putString("engine_name", value).apply()

    /** 选中的音色（TTS voice 名），空表示自动挑。 */
    var voiceId: String
        get() = sp.getString("voice_id", "") ?: ""
        set(value) = sp.edit().putString("voice_id", value).apply()

    /** 音调，1.0 为原声。 */
    var voicePitch: Float
        get() = sp.getFloat("voice_pitch", 1.12f)
        set(value) = sp.edit().putFloat("voice_pitch", value).apply()

    /** 语速。 */
    var voiceRate: Float
        get() = sp.getFloat("voice_rate", 0.98f)
        set(value) = sp.edit().putFloat("voice_rate", value).apply()

    /** 是否朗读回复。 */
    var speakEnabled: Boolean
        get() = sp.getBoolean("speak", true)
        set(value) = sp.edit().putBoolean("speak", value).apply()

    /** 悬浮窗宽度（dp），双指缩放后写回。 */
    var petWidthDp: Int
        get() = sp.getInt("pet_width_dp", 150)
        set(value) = sp.edit().putInt("pet_width_dp", value).apply()
}
