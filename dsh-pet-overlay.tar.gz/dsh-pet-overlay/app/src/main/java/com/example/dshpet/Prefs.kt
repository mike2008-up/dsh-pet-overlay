package com.example.dshpet

import android.content.Context

/**
 * 只存三样东西：DSH 基地址、连接用 cookie、上次填的启动地址。
 * 明文 SharedPreferences 就够了，这里没有敏感凭据以外的内容。
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("dsh_pet", Context.MODE_PRIVATE)

    var baseUrl: String
        get() = sp.getString("base_url", "http://127.0.0.1:3080") ?: "http://127.0.0.1:3080"
        set(value) = sp.edit().putString("base_url", value).apply()

    var cookie: String?
        get() = sp.getString("cookie", null)
        set(value) = sp.edit().putString("cookie", value).apply()

    var launchUrl: String
        get() = sp.getString("launch_url", "") ?: ""
        set(value) = sp.edit().putString("launch_url", value).apply()

    /** 悬浮窗宽度（dp），双指缩放后写回。 */
    var petWidthDp: Int
        get() = sp.getInt("pet_width_dp", 150)
        set(value) = sp.edit().putInt("pet_width_dp", value).apply()
}
