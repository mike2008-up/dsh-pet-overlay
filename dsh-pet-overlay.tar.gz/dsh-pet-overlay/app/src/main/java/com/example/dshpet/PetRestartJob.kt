package com.example.dshpet

import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.os.Build

/**
 * 看护任务：每 15 分钟检查一次，桌面宠物被杀掉了就重新拉起。
 * 系统级持久任务（setPersisted），重启后依然有效。
 */
class PetRestartJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        val prefs = Prefs(this)
        if (prefs.cookie == null) return false
        val intent = Intent(this, PetOverlayService::class.java)
            .setAction(PetOverlayService.ACTION_START)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        }
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
