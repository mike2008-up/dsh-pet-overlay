package com.example.dshpet

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { Prefs(this) }
    private lateinit var status: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        input = EditText(this).apply {
            hint = "粘贴连接串：baseUrl|cookie 或 带 ?token= 的地址"
            setText(prefs.launchUrl)
            setSingleLine(false)
        }
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }

        root.addView(TextView(this).apply { text = "DSH 桌宠"; textSize = 22f })
        root.addView(TextView(this).apply { text = "顺序：① 授权悬浮窗 → ② 连接 DSH → ③ 启动桌宠" })
        root.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(button("① 授予悬浮窗权限") { requestOverlay() })
        root.addView(button("② 连接 DSH（换 cookie）") { connect() })
        root.addView(button("③ 启动桌宠") { startPet() })
        root.addView(button("停止桌宠") { stopPet() })
        root.addView(status)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { action() }
        }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            toast("已经有悬浮窗权限了")
            refreshStatus()
            return
        }
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun connect() {
        val url = input.text.toString().trim()
        if (url.isEmpty()) {
            toast("先把连接串粘进来")
            return
        }
        // 直接粘贴 cookie（或以 baseUrl|cookie 形式粘贴）时无需再换 token，
        // 好处是 DSH 重启后 cookie 依然有效
        if (url.startsWith("dsh-auth-") || url.contains('|')) {
            val parts = url.split('|', limit = 2)
            if (parts.size == 2) {
                prefs.baseUrl = parts[0].trim()
                prefs.cookie = parts[1].trim()
            } else {
                prefs.baseUrl = "http://127.0.0.1:3080"
                prefs.cookie = url
            }
            refreshStatus()
            toast("连接串已保存")
            return
        }
        prefs.launchUrl = url
        status.text = "正在连接…"
        Thread {
            val result = DshClient(prefs).exchange(url)
            runOnUiThread {
                status.text = result.fold(
                    { "已连接：${prefs.baseUrl}" },
                    { "失败：${it.message}" }
                )
            }
        }.start()
    }

    private fun startPet() {
        if (!Settings.canDrawOverlays(this)) {
            toast("先授予悬浮窗权限")
            return
        }
        if (prefs.cookie == null) {
            toast("先点②连接 DSH")
            return
        }
        val intent = Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_START)
        startForegroundService(intent)
        toast("桌宠已启动，现在可以切到别的应用看")
    }

    private fun stopPet() {
        startService(Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_STOP))
        toast("已停止")
    }

    private fun refreshStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "已授权" else "未授权"
        val cookie = if (prefs.cookie == null) "未连接" else "已连接"
        status.text = "悬浮窗：$overlay\nDSH：$cookie（${prefs.baseUrl}）"
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
