package com.example.dshpet

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.content.Context
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { Prefs(this) }
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var chatInput: EditText
    private lateinit var replyView: TextView
    private lateinit var voiceStatus: TextView
    private val speaker by lazy { Speaker(this, Prefs(this)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        input = EditText(this).apply {
            hint = "粘贴连接串：baseUrl|cookie 或 带 ?token= 的地址"
            setText(prefs.launchUrl)
            setSingleLine(false)
        }
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }

        root.addView(TextView(this).apply { text = "DSH 桌宠"; textSize = 22f })
        root.addView(TextView(this).apply { text = "v24 · 划掉后台也在"; textSize = 13f })
        root.addView(TextView(this).apply { text = "顺序：① 授权悬浮窗 → ② 连接 DSH → ③ 启动桌宠" })
        root.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(button("① 一键授权（悬浮窗/通知/后台）") { grantAll() })
        root.addView(button("② 连接 DSH（换 cookie）") { connect() })
        root.addView(button("③ 启动桌宠") { startPet() })
        root.addView(button("停止桌宠") { stopPet() })
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "和她说话"
            textSize = 18f
            setPadding(0, pad * 2, 0, pad / 2)
        })
        chatInput = EditText(this).apply { hint = "说点什么…" }
        root.addView(
            chatInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(button("发送") { sendChat() })
        root.addView(button("打开系统语音设置") {
            runCatching { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        })
        root.addView(button("选择引擎") { pickEngine() })
        root.addView(button("选择音色") { pickVoice() })
        root.addView(button("试听语音") { speaker.speak("主人好呀，我是你的鲸鱼娘，今天也要记得休息哦") })

        // 音调滑块：0.7 ～ 1.6
        val pitchLabel = TextView(this).apply { text = "音调：${"%.2f".format(prefs.voicePitch)}" }
        root.addView(pitchLabel)
        root.addView(SeekBar(this).apply {
            max = 90
            progress = ((prefs.voicePitch - 0.7f) / 0.9f * 90).toInt().coerceIn(0, 90)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    val pitch = 0.7f + value / 90f * 0.9f
                    pitchLabel.text = "音调：${"%.2f".format(pitch)}"
                    if (fromUser) speaker.setPitch(pitch)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    speaker.speak("这个音调可以吗")
                }
            })
        })

        // 语速滑块：0.6 ～ 1.4
        val rateLabel = TextView(this).apply { text = "语速：${"%.2f".format(prefs.voiceRate)}" }
        root.addView(rateLabel)
        root.addView(SeekBar(this).apply {
            max = 80
            progress = ((prefs.voiceRate - 0.6f) / 0.8f * 80).toInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    val rate = 0.6f + value / 80f * 0.8f
                    rateLabel.text = "语速：${"%.2f".format(rate)}"
                    if (fromUser) speaker.setRate(rate)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    speaker.speak("这个语速可以吗")
                }
            })
        })
        voiceStatus = TextView(this).apply {
            text = "语音状态：等待引擎初始化"
            textSize = 12f
            setPadding(0, pad / 3, 0, pad)
        }
        root.addView(voiceStatus)
        root.addView(
            CheckBox(this).apply {
                text = "朗读回复（系统语音合成）"
                isChecked = prefs.speakEnabled
                setOnCheckedChangeListener { _, checked -> prefs.speakEnabled = checked }
            }
        )
        replyView = TextView(this).apply { setPadding(0, pad / 2, 0, pad) }
        root.addView(replyView)

        setContentView(ScrollView(this).apply { addView(root) })

        speaker.onStatus = { message ->
            runOnUiThread { voiceStatus.text = "语音状态：$message" }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refreshStatus()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { action() }
        }

    /** 把运行需要的权限一次引到位：悬浮窗、通知、电池优化白名单。 */
    private fun grantAll() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlay()
            toast("先打开「显示在其他应用上层」，回来再点一次")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!power.isIgnoringBatteryOptimizations(packageName)) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        }
        val ttsIntent = Intent("com.android.settings.TTS_SETTINGS")
        runCatching { startActivity(ttsIntent) }
        refreshStatus()
        toast("按提示把开关都打开即可")
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            toast("已经有悬浮窗权限了")
            refreshStatus()
            return
        }
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun connect() {
        val url = input.text.toString().trim()
        if (url.isEmpty()) {
            toast("先把连接串粘进来")
            return
        }
        // 直接粘贴 cookie（或以 baseUrl|cookie 形式粘贴）时无需再换 token，
        // 好处是 DSH 重启后 cookie 依然有效
        if (url.startsWith("dsh-auth-") || url.contains('|')) {
            val parts = url.split('|', limit = 2)
            if (parts.size == 2) {
                prefs.baseUrl = parts[0].trim()
                prefs.cookie = parts[1].trim()
            } else {
                prefs.baseUrl = "http://127.0.0.1:3080"
                prefs.cookie = url
            }
            refreshStatus()
            toast("连接串已保存")
            return
        }
        prefs.launchUrl = url
        status.text = "正在连接…"
        Thread {
            val result = DshClient(prefs).exchange(url)
            runOnUiThread {
                status.text = result.fold(
                    { "已连接：${prefs.baseUrl}" },
                    { "失败：${it.message}" }
                )
            }
        }.start()
    }

    /** 列出手机里所有中文音色，点一个就试听并记住。 */
    /** 切换系统 TTS 引擎（不同引擎音色完全不同）。 */
    private fun pickEngine() {
        val engines = speaker.engines()
        if (engines.isEmpty()) {
            toast("系统里没有可用的语音引擎")
            return
        }
        val current = prefs.engineName.ifEmpty { "系统默认" }
        AlertDialog.Builder(this)
            .setTitle("选择语音引擎（当前：$current）")
            .setItems(engines.toTypedArray()) { _, which ->
                val picked = engines[which]
                speaker.switchEngine(picked)
                voiceStatus.text = "语音状态：正在切换到 $picked"
                Thread {
                    Thread.sleep(1200)
                    runOnUiThread { speaker.speak("换好引擎啦，你听听这个声音") }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun pickVoice() {
        val voices = speaker.availableVoices()
        if (voices.isEmpty()) {
            toast("这个引擎不单独暴露音色，试试「选择引擎」换一个")
            return
        }
        val labels = voices.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("选择音色（当前：${prefs.voiceId.ifEmpty { "自动" }}）")
            .setItems(labels) { _, which ->
                val picked = voices[which]
                speaker.selectVoice(picked.id, preview = "这个音色怎么样呀")
                voiceStatus.text = "语音状态：已选 ${picked.label}"
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun startPet() {
        if (!Settings.canDrawOverlays(this)) {
            toast("先授予悬浮窗权限")
            return
        }
        if (prefs.cookie == null) {
            toast("先点②连接 DSH")
            return
        }
        val intent = Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_START)
        startForegroundService(intent)
        scheduleWatchdog()
        toast("桌宠已启动，现在可以切到别的应用看")
    }

    private fun sendChat() {
        val text = chatInput.text.toString().trim()
        if (text.isEmpty()) return
        if (prefs.cookie == null) {
            toast("先点②连接 DSH")
            return
        }
        replyView.text = "……"
        Thread {
            val result = DshClient(prefs).chat(text)
            runOnUiThread {
                result.fold(
                    { (say, _) ->
                        replyView.text = "她：$say"
                        chatInput.setText("")
                        if (prefs.speakEnabled) speaker.speak(say)
                    },
                    { replyView.text = "失败：${it.message}" }
                )
            }
        }.start()
    }

    /** 每 15 分钟自查一次，被杀掉就自动拉起来。 */
    private fun scheduleWatchdog() {
        val scheduler = getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler
        val component = ComponentName(this, PetRestartJob::class.java)
        val job = JobInfo.Builder(1001, component)
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true)
            .build()
        runCatching { scheduler.schedule(job) }
    }

    private fun stopPet() {
        runCatching {
            val scheduler = getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler
            scheduler.cancel(1001)
        }
        startService(Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_STOP))
        toast("已停止")
    }

    private fun refreshStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "已授权" else "未授权"
        val cookie = if (prefs.cookie == null) "未连接" else "已连接"
        status.text = "悬浮窗：$overlay\nDSH：$cookie（${prefs.baseUrl}）"
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
