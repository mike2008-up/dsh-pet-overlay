package com.example.dshpet

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * DSH 的 HTTP 接口全部在登录态后面，浏览器用的是 cookie。
 * 这里复用同一套机制：
 *   1) 拿 `dsh web` 打印的带 token 地址，去 /connect 换一颗 cookie
 *   2) 之后每次带 cookie 轮询宠物的 /state
 *
 * 注意：/connect 的响应是 302 + Set-Cookie，所以必须关掉自动重定向。
 */
class DshClient(private val prefs: Prefs) {

    data class Snapshot(val say: String?, val image: String?, val working: Boolean)

    /** 用启动地址换 cookie，成功返回这颗 cookie 的键值对。 */
    fun exchange(launchUrl: String): Result<String> = runCatching {
        val token = Regex("[?&]token=([^&]+)").find(launchUrl)?.groupValues?.get(1)
            ?: error("地址里没有 token 参数")
        val origin = URL(launchUrl).let { "${it.protocol}://${it.authority}" }
        val conn = URL("$origin/connect?interactions=none&token=$token").openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = false
        conn.requestMethod = "GET"
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try {
            val code = conn.responseCode
            val raw = conn.getHeaderField("Set-Cookie")
                ?: error("服务端没有下发 cookie（HTTP $code）")
            val cookie = raw.substringBefore(';')
            prefs.cookie = cookie
            prefs.baseUrl = origin
            cookie
        } finally {
            conn.disconnect()
        }
    }

    /** 读一次宠物状态；任何失败都返回 null，界面按“离线”显示。 */
    fun fetchState(): Snapshot? = runCatching {
        val cookie = prefs.cookie ?: return null
        val base = prefs.baseUrl.trimEnd('/')
        val conn = URL("$base/dsh-pet-7340/state").openConnection() as HttpURLConnection
        conn.setRequestProperty("Cookie", cookie)
        conn.connectTimeout = 5000
        conn.readTimeout = 5000
        try {
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val say = json.optJSONObject("pets")
                ?.optJSONObject("main")
                ?.optJSONObject("say")
                ?.optJSONObject("data")
                ?.optString("text")
                ?.takeIf { it.isNotBlank() }
            val image = json.optJSONObject("pets")
                ?.optJSONObject("main")
                ?.optJSONObject("say")
                ?.optJSONObject("data")
                ?.optString("image")
                ?.takeIf { it.isNotBlank() }
            val state = json.optJSONObject("sections")
                ?.optJSONObject("workStatus")
                ?.optJSONObject("data")
                ?.optString("state")
            Snapshot(say, image, state == "working")
        } finally {
            conn.disconnect()
        }
    }.getOrNull()

    /** 跟宠物说一句话；返回它的回复和想要的表情。 */
    fun chat(text: String): Result<Pair<String, String?>> = runCatching {
        val cookie = prefs.cookie ?: error("还没连接 DSH")
        val base = prefs.baseUrl.trimEnd('/')
        val conn = URL("$base/dsh-pet-7340/chat?pet=main&surface=web").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Cookie", cookie)
        conn.setRequestProperty("content-type", "application/json")
        conn.connectTimeout = 10000
        conn.readTimeout = 90000
        conn.outputStream.use { it.write(JSONObject().put("text", text).toString().toByteArray()) }
        try {
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (!json.optBoolean("ok")) error(json.optString("message", "对话失败"))
            val reply = json.optString("text")
            val image = json.optString("image").takeIf { it.isNotEmpty() }
            reply to image
        } finally {
            conn.disconnect()
        }
    }
}
