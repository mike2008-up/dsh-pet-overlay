package com.example.dshpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 前台服务 + WindowManager 悬浮窗。
 * 悬浮窗类型是 TYPE_APPLICATION_OVERLAY：只有拿到 SYSTEM_ALERT_WINDOW 才能加到别的应用之上。
 */
class PetOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.example.dshpet.START"
        const val ACTION_STOP = "com.example.dshpet.STOP"
        private const val CHANNEL_ID = "dsh_pet_overlay"
        private const val NOTIFICATION_ID = 42
    }

    private lateinit var windowManager: WindowManager
    private var petView: PetView? = null
    private var params: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val prefs by lazy { Prefs(this) }
    private val client by lazy { DshClient(prefs) }
    private lateinit var scaleDetector: ScaleGestureDetector
    private var autoWalk = true
    private var walkDirection = 1
    private var lastTouchAt = 0L

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val lp = params ?: return false
                val width = (lp.width * detector.scaleFactor).toInt().coerceIn(
                    (120 * resources.displayMetrics.density).toInt(),
                    (420 * resources.displayMetrics.density).toInt(),
                )
                lp.height = (width * (330f / 250f)).toInt()
                lp.width = width
                petView?.let { view -> windowManager.updateViewLayout(view, lp) }
                prefs.petWidthDp = (width / resources.displayMetrics.density).toInt()
                return true
            }
        })
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                showPet()
                startPolling()
            }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "桌宠", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("DSH 桌宠")
            .setContentText("正在其他应用上层显示")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    private fun showPet() {
        if (petView != null) return
        val density = resources.displayMetrics.density
        val width = (prefs.petWidthDp * density).toInt()
        val view = PetView(this)
        val lp = WindowManager.LayoutParams(
            width,
            (width * (330f / 250f)).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 320
        }
        attachDrag(view, lp)
        windowManager.addView(view, lp)
        petView = view
        params = lp
        startWalking()
    }

    /** 让宠物自己在屏幕上走动，碰到边缘掉头；用户拖动时暂停。 */
    private fun startWalking() {
        scope.launch {
            while (isActive) {
                val lp = params
                val view = petView
                if (lp != null && view != null && autoWalk) {
                    val maxX = resources.displayMetrics.widthPixels - lp.width
                    lp.x += walkDirection * if (lastPose == "happy") 4 else 1
                    if (lp.x <= 0) { lp.x = 0; walkDirection = 1 }
                    if (lp.x >= maxX) { lp.x = maxX; walkDirection = -1 }
                    runCatching { windowManager.updateViewLayout(view, lp) }
                }
                delay(40)
            }
        }
    }

    private var lastPose: String = "idle"


    private fun attachDrag(view: PetView, lp: WindowManager.LayoutParams) {
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                startActivity(
                    Intent(this@PetOverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            scaleDetector.onTouchEvent(event)
            if (scaleDetector.isInProgress) return@setOnTouchListener true
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    autoWalk = false
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lastTouchAt = System.currentTimeMillis()
                    val view0 = v
                    scope.launch {
                        delay(3000)
                        if (System.currentTimeMillis() - lastTouchAt >= 2900 && params !== null) autoWalk = true
                    }
                    view0.performClick()
                    false
                }
                else -> false
            }
        }
    }

    private fun startPolling() {
        scope.launch {
            while (isActive) {
                val snapshot = withContext(Dispatchers.IO) { client.fetchState() }
                val view = petView ?: break
                lastPose = if (snapshot != null && snapshot.working) "happy" else "idle"
                if (snapshot == null) {
                    view.pose = "offline"
                    view.speech = "连不上 DSH…"
                } else {
                    view.pose = snapshot.image ?: if (snapshot.working) "happy" else "idle"
                    view.speech = snapshot.say
                }
                delay(5000)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        petView?.let { view -> runCatching { windowManager.removeView(view) } }
        petView = null
        super.onDestroy()
    }
}
