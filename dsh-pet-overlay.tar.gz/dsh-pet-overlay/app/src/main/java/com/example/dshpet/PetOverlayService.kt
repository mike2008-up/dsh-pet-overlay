package com.example.dshpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 前台服务 + WindowManager 悬浮窗。
 * 悬浮窗类型是 TYPE_APPLICATION_OVERLAY：只有拿到 SYSTEM_ALERT_WINDOW 才能加到别的应用之上。
 */
class PetOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.example.dshpet.START"
        const val ACTION_STOP = "com.example.dshpet.STOP"
        private const val CHANNEL_ID = "dsh_pet_overlay"
        private const val NOTIFICATION_ID = 42
    }

    private lateinit var windowManager: WindowManager
    private var petView: PetView? = null
    private var params: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val client by lazy { DshClient(Prefs(this)) }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                showPet()
                startPolling()
            }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "桌宠", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("DSH 桌宠")
            .setContentText("正在其他应用上层显示")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    private fun showPet() {
        if (petView != null) return
        val density = resources.displayMetrics.density
        val view = PetView(this)
        val lp = WindowManager.LayoutParams(
            (250 * density).toInt(),
            (330 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 320
        }
        attachDrag(view, lp)
        windowManager.addView(view, lp)
        petView = view
        params = lp
    }

    private fun attachDrag(view: PetView, lp: WindowManager.LayoutParams) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(v, lp)
                    true
                }
                else -> false
            }
        }
    }

    private fun startPolling() {
        scope.launch {
            while (isActive) {
                val snapshot = withContext(Dispatchers.IO) { client.fetchState() }
                val view = petView ?: break
                if (snapshot == null) {
                    view.working = false
                    view.speech = "连不上 DSH…"
                } else {
                    view.working = snapshot.working
                    view.speech = snapshot.say
                }
                delay(5000)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        petView?.let { view -> runCatching { windowManager.removeView(view) } }
        petView = null
        super.onDestroy()
    }
}
