package com.example.dshpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 前台服务 + WindowManager 悬浮窗。
 * 悬浮窗类型是 TYPE_APPLICATION_OVERLAY：只有拿到 SYSTEM_ALERT_WINDOW 才能加到别的应用之上。
 */
class PetOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.example.dshpet.START"
        const val ACTION_STOP = "com.example.dshpet.STOP"
        private const val CHANNEL_ID = "dsh_pet_overlay"
        private const val NOTIFICATION_ID = 42
    }

    private lateinit var windowManager: WindowManager
    private var petView: PetView? = null
    private var params: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val prefs by lazy { Prefs(this) }
    private val client by lazy { DshClient(prefs) }
    private val speaker by lazy { Speaker(this, prefs) }
    private var panel: LinearLayout? = null
    private lateinit var scaleDetector: ScaleGestureDetector
    private var autoWalk = true
    private var walkDirection = 1
    private var lastTouchAt = 0L

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val lp = params ?: return false
                val width = (lp.width * detector.scaleFactor).toInt().coerceIn(
                    (120 * resources.displayMetrics.density).toInt(),
                    (420 * resources.displayMetrics.density).toInt(),
                )
                lp.height = (width * (300f / 240f)).toInt()
                lp.width = width
                petView?.let { view -> windowManager.updateViewLayout(view, lp) }
                prefs.petWidthDp = (width / resources.displayMetrics.density).toInt()
                return true
            }
        })
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                showPet()
                startPolling()
            }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "桌宠", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("DSH 桌宠")
            .setContentText("正在其他应用上层显示")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    /** 在其他应用上方直接聊天：可聚焦、能弹键盘的面板。 */
    private fun togglePanel() {
        panel?.let { hidePanel(); return }
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * density).toInt(), (12 * density).toInt(), (14 * density).toInt(), (12 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 16 * density
                setColor(0xF2FFFFFF.toInt())
                setStroke((1 * density).toInt(), 0x33000000)
            }
        }
        val input = EditText(this).apply {
            hint = "说点什么…"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        val reply = TextView(this).apply {
            text = "输入一句话后按发送"
            setPadding(0, (8 * density).toInt(), 0, (8 * density).toInt())
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val send = Button(this).apply { text = "发送" }
        val close = Button(this).apply { text = "收起" }
        row.addView(send, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(close, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(reply, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val width = minOf(resources.displayMetrics.widthPixels - (24 * density).toInt(), (320 * density).toInt())
        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * density).toInt()
            y = (160 * density).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
        }
        windowManager.addView(root, lp)
        panel = root

        val submit = {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                reply.text = "……"
                scope.launch {
                    val result = withContext(Dispatchers.IO) { client.chat(text) }
                    result.fold(
                        { (say, image) ->
                            reply.text = "她：$say"
                            val pet = petView
                            pet?.speech = say
                            val emote = image?.let { emoteFromImage(it) } ?: emoteFromText(say)
                            pet?.showEmote(emote, 2600)
                            pet?.play(actionForEmote(emote))
                            pet?.speak()
                            if (prefs.speakEnabled) speaker.speak(say)
                        },
                        { reply.text = "失败：${it.message}" }
                    )
                }
            }
        }
        send.setOnClickListener { submit() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }
        close.setOnClickListener { hidePanel() }
        input.requestFocus()
    }

    /** 插件给的表情名 → 情绪符号。 */
    private fun emoteFromImage(image: String): String = when {
        image.contains("睡") -> "zzz"
        image.contains("死") || image.contains("难过") -> "tear"
        image.contains("电") || image.contains("烧") -> "anger"
        image.contains("可爱") || image.contains("调情") -> "heart"
        image.contains("厉害") || image.contains("开源") -> "exclaim"
        else -> "note"
    }

    private fun emoteFromText(text: String): String = when {
        Regex("哈|开心|高兴|好耶|棒|喜欢").containsMatchIn(text) -> "heart"
        Regex("哼|生气|讨厌|不理你").containsMatchIn(text) -> "anger"
        Regex("呜|难过|委屈|哭").containsMatchIn(text) -> "tear"
        Regex("困|睡|晚安|累").containsMatchIn(text) -> "zzz"
        Regex("？|\?").containsMatchIn(text) -> "question"
        else -> "note"
    }

    private fun actionForEmote(emote: String): String = when (emote) {
        "zzz", "tear" -> "nod"
        "anger" -> "shake"
        "heart" -> "jump"
        "exclaim" -> "bounce"
        else -> "wave"
    }

    private fun hidePanel() {
        panel?.let { view -> runCatching { windowManager.removeView(view) } }
        panel = null
    }

    private fun showPet() {
        if (petView != null) return
        val density = resources.displayMetrics.density
        val width = (prefs.petWidthDp * density).toInt()
        val view = PetView(this)
        val lp = WindowManager.LayoutParams(
            width,
            (width * (300f / 240f)).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // 默认落在屏幕左下角
            x = (16 * density).toInt()
            val screenHeight = resources.displayMetrics.heightPixels
            y = (screenHeight - (width * (300f / 240f)).toInt() - (28 * density).toInt()).coerceAtLeast(0)
        }
        attachDrag(view, lp)
        windowManager.addView(view, lp)
        petView = view
        params = lp
        startWalking()
    }

    /** 让宠物自己在屏幕上走动，碰到边缘掉头；用户拖动时暂停。 */
    private fun startWalking() {
        scope.launch {
            while (isActive) {
                val lp = params
                val view = petView
                if (lp != null && view != null && autoWalk) {
                    val maxX = resources.displayMetrics.widthPixels - lp.width
                    // 60fps：每帧最多走 1px，用累计器把速度折算成小数
                    walkAccumulator += if (lastPose == "happy") 2.2f else 1.1f
                    val step = walkAccumulator.toInt()
                    if (step > 0) {
                        walkAccumulator -= step
                        lp.x += walkDirection * step
                        if (lp.x <= 0) { lp.x = 0; walkDirection = 1 }
                        if (lp.x >= maxX) { lp.x = maxX; walkDirection = -1 }
                        runCatching { windowManager.updateViewLayout(view, lp) }
                    }
                }
                delay(16)
            }
        }
    }

    private var lastPose: String = "normal"
    private var walkAccumulator = 0f
    private var lastSpeech: String? = null


    private fun attachDrag(view: PetView, lp: WindowManager.LayoutParams) {
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                startActivity(
                    Intent(this@PetOverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            scaleDetector.onTouchEvent(event)
            if (scaleDetector.isInProgress) return@setOnTouchListener true
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    autoWalk = false
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lastTouchAt = System.currentTimeMillis()
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val moved = kotlin.math.abs(event.rawX - downX) + kotlin.math.abs(event.rawY - downY)
                        if (moved < 12) togglePanel()
                    }
                    val view0 = v
                    scope.launch {
                        delay(3000)
                        if (System.currentTimeMillis() - lastTouchAt >= 2900 && params !== null) autoWalk = true
                    }
                    view0.performClick()
                    false
                }
                else -> false
            }
        }
    }

    private fun startPolling() {
        scope.launch {
            while (isActive) {
                val snapshot = withContext(Dispatchers.IO) { client.fetchState() }
                val view = petView ?: break
                lastPose = if (snapshot != null && snapshot.working) "happy" else "normal"
                if (snapshot == null) {
                    view.showEmote("tear")
                    view.speech = "连不上 DSH…"
                } else {
                    snapshot.image?.let { image -> view.showEmote(emoteFromImage(image), 2600) }
                    val next = snapshot.say
                    if (next != null && next != lastSpeech) {
                        lastSpeech = next
                        view.speech = next
                        view.speak()
                        view.play(if (snapshot.working) "jump" else "nod")
                    } else if (next == null) {
                        view.speech = null
                    }
                }
                delay(5000)
            }
        }
    }

    override fun onDestroy() {
        hidePanel()
        speaker.shutdown()
        scope.cancel()
        petView?.let { view -> runCatching { windowManager.removeView(view) } }
        petView = null
        super.onDestroy()
    }
}
