package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * 鲸鱼娘精灵：表情来自抠好的透明 PNG（27 种，按插件返回的表情名切换）。
 *
 * 动作：上下浮动/呼吸/说话脉动，另有一次性动作 jump / shake / nod，
 * 空闲时会随机做个小动作。
 */
class PetView(context: Context) : View(context) {

    private var phase = 0f
    private var talkUntil = 0L
    private var actionStartedAt = 0L
    private var actionName = ""
    private var nextIdleActionAt = System.currentTimeMillis() + 18000
    private var nextIdleMoodAt = System.currentTimeMillis() + 30000
    private var overlayMood: String? = null
    private var overlayUntil = 0L

    /** 表情名：memes.json 里的中文名，或 normal / happy / sleep */
    var mood: String = "normal"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val memes: Map<String, String> by lazy {
        runCatching {
            val raw = context.assets.open("pet/memes.json").use { it.readBytes().toString(Charsets.UTF_8) }
            val json = JSONObject(raw)
            json.keys().asSequence().associateWith { key -> json.getString(key) }
        }.getOrDefault(emptyMap())
    }

    private val cache = HashMap<String, Bitmap?>()

    private fun sprite(): Bitmap? {
        val key = if (System.currentTimeMillis() < overlayUntil && overlayMood != null) overlayMood!! else mood
        if (cache.containsKey(key)) return cache[key]
        val candidates = buildList {
            memes[key]?.let { add("pet/memes/$it") }
            add("pet/$key.png")
            add("pet/normal.png")
        }
        var loaded: Bitmap? = null
        for (path in candidates) {
            loaded = runCatching {
                context.assets.open(path).use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (loaded != null) break
        }
        cache[key] = loaded
        return loaded
    }

    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F7FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 26f
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    /** 说话：动嘴脉动。 */
    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        invalidate()
    }

    /** 一次性动作：jump / shake / nod。 */
    fun play(action: String) {
        actionName = action
        actionStartedAt = System.currentTimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        val bob = sin(phase) * height * 0.012f
        val breathe = 1f + sin(phase * 2f) * 0.015f
        val talking = now < talkUntil
        val pulse = if (talking) 1f + sin(phase * 6f) * 0.02f else 1f

        // 空闲时随机做个小动作
        if (now >= nextIdleActionAt) {
            val pool = listOf("jump", "nod", "wave", "bounce", "lean", "squash", "shake", "spin")
            play(pool[(Math.random() * pool.size).toInt()])
            nextIdleActionAt = now + 18000 + (Math.random() * 12000).toLong()
        }

        // 空闲自娱自乐：换表情 + 做动作
        if (now >= nextIdleMoodAt) {
            val pool = listOf(
                "可爱", "厉害了我的鲸", "哦鲸鲸", "吃饱饱摸肚子",
                "先养着吧", "大师这个区是什么意思", "黎曼猜想没证明喵", "Ciallo",
            )
            overlayMood = pool[(Math.random() * pool.size).toInt()]
            overlayUntil = now + 4200
            nextIdleMoodAt = now + 30000 + (Math.random() * 20000).toLong()
        }

        // 一次性动作的位移/旋转
        var dx = 0f
        var dy = 0f
        var rotation = 0f
        var squash = 1f
        if (actionStartedAt > 0L) {
            val duration = when (actionName) {
                "jump" -> 620f
                "shake" -> 520f
                "nod" -> 680f
                "wave" -> 900f
                "spin" -> 900f
                "bounce" -> 800f
                "lean" -> 620f
                "squash" -> 520f
                else -> 0f
            }
            if (duration > 0f) {
                val t = (now - actionStartedAt) / duration
                if (t in 0f..1f) {
                    val p = PI.toFloat()
                    when (actionName) {
                        "jump" -> dy = -height * 0.09f * sin(p * t)
                        "shake" -> dx = width * 0.035f * sin(t * p * 6) * (1 - t)
                        "nod" -> rotation = 7f * sin(t * p * 2) * (1 - t)
                        "wave" -> {
                            rotation = 10f * sin(t * p * 3) * (1 - t)
                            dx = width * 0.02f * sin(t * p * 2) * (1 - t)
                        }
                        "spin" -> rotation = 360f * t
                        "bounce" -> dy = -height * 0.05f * abs(sin(t * p * 2))
                        "lean" -> rotation = 9f * sin(t * p) * (1 - t)
                        "squash" -> squash = 1f - 0.07f * sin(p * t)
                    }
                }
            }
        }

        val bitmap = sprite()
        if (bitmap != null) {
            val availableHeight = height * 0.86f
            val scale = minOf(width / bitmap.width.toFloat(), availableHeight / bitmap.height.toFloat()) * breathe * pulse
            val drawWidth = bitmap.width * scale
            val drawHeight = bitmap.height * scale
            val left = (width - drawWidth) / 2f + dx
            val top = height - drawHeight + bob + dy
            canvas.save()
            canvas.rotate(rotation, width / 2f, top + drawHeight * 0.6f)
            canvas.scale(1f / squash, squash, width / 2f, top + drawHeight)
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + drawWidth, top + drawHeight), null)
            canvas.restore()
        }

        speech?.let { drawBubble(canvas, it) }
    }

    private fun drawBubble(canvas: Canvas, text: String) {
        val maxWidth = width * 0.94f
        val lines = wrap(text, maxWidth - 24f)
        val lineHeight = textPaint.textSize * 1.35f
        val heightBox = lines.size * lineHeight + 20f
        val boxWidth = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 24f)
        val left = (width - boxWidth) / 2f
        val box = RectF(left, 0f, left + boxWidth, heightBox)
        canvas.drawRoundRect(box, 14f, 14f, bubble)
        var y = box.top + 12f + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 12f, y, textPaint)
            y += lineHeight
        }
        val tail = Path().apply {
            moveTo(width / 2f - 8f, box.bottom)
            lineTo(width / 2f, box.bottom + 10f)
            lineTo(width / 2f + 8f, box.bottom)
            close()
        }
        canvas.drawPath(tail, bubble)
    }

    private fun wrap(text: String, maxWidth: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > maxWidth) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
