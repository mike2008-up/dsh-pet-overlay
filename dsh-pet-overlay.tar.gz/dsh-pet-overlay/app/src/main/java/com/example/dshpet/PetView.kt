package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * 纯矢量绘制的 Q 版鲸鱼娘（不使用任何图片）。
 * 特征照参考图还原：蕾丝头纱 + 呆毛、两侧蓝蝴蝶结、鳍状耳发、长卷发、
 * 深蓝连衣裙 + 白围裙 + 胸口蝴蝶结、鲸尾、深色裤袜。
 *
 * 坐标系固定 240×320，整体缩放到控件大小。
 * 动画：呼吸、眨眼、尾巴摆动、说话动嘴、轻微摆头。
 */
class PetView(context: Context) : View(context) {

    private companion object {
        const val W = 240f
        const val H = 320f
    }

    private var phase = 0f
    private var blinkUntil = 0L
    private var nextBlinkAt = System.currentTimeMillis() + 2600
    private var talkUntil = 0L

    var expression: String = "normal"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val hairDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2E4F91") }
    private val hairMid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3C68BE") }
    private val hairLight = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5C8CE0") }
    private val skin = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFE6D6") }
    private val dress = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1F3563") }
    private val apron = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F8FAFF") }
    private val lace = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFFFFF") }
    private val tailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#26507F") }
    private val eyeWhite = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val iris = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2E6FD2") }
    private val irisDeep = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#173B7A") }
    private val lash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1B2A47")
        style = Paint.Style.STROKE
        strokeWidth = 3.4f
        strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C9736F")
        style = Paint.Style.STROKE
        strokeWidth = 2.4f
        strokeCap = Paint.Cap.ROUND
    }
    private val blush = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF9DBB") }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 12f
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3400
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            maybeBlink()
            invalidate()
        }
        start()
    }

    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        invalidate()
    }

    private fun maybeBlink() {
        val now = System.currentTimeMillis()
        if (now >= nextBlinkAt) {
            blinkUntil = now + 130
            nextBlinkAt = now + 2400 + (Math.random() * 2600).toLong()
        }
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(width / W, height / H)

        val bob = sin(phase) * 3.5f
        val breathe = 1f + sin(phase * 2f) * 0.012f
        val tilt = sin(phase * 0.8f) * 1.8f
        val now = System.currentTimeMillis()
        val blinking = now < blinkUntil
        val talking = now < talkUntil

        drawTail(canvas, bob)
        drawHairBack(canvas, bob)
        drawBody(canvas, bob)
        canvas.save()
        canvas.rotate(tilt, 120f, 170f)
        canvas.translate(120f, 150f + bob)
        canvas.scale(1f, breathe)
        canvas.translate(-120f, -150f)
        drawFinEars(canvas, bob)
        drawFace(canvas, bob)
        drawBangs(canvas, bob)
        drawHeadband(canvas, bob)
        drawEyes(canvas, bob, blinking)
        drawMouth(canvas, bob, talking)
        canvas.restore()

        speech?.let { drawBubble(canvas, it, 120f, 34f) }
        canvas.restore()
    }

    // ---------- 身体 ----------

    private fun drawTail(canvas: Canvas, bob: Float) {
        val sway = sin(phase * 1.6f) * 6f
        val p = Path().apply {
            moveTo(150f, 268f + bob)
            cubicTo(178f, 252f + bob + sway, 202f, 240f + bob + sway, 214f, 232f + bob + sway)
            cubicTo(206f, 252f + bob + sway, 206f, 274f + bob + sway, 214f, 292f + bob + sway)
            cubicTo(192f, 282f + bob + sway, 168f, 276f + bob, 150f, 268f + bob)
            close()
        }
        canvas.drawPath(p, tailPaint)
    }

    private fun drawHairBack(canvas: Canvas, bob: Float) {
        // 后长发：上方贴头，下摆做成波浪
        val p = Path().apply {
            moveTo(58f, 96f + bob)
            cubicTo(48f, 150f + bob, 52f, 208f + bob, 40f, 258f + bob)
            cubicTo(58f, 250f + bob, 70f, 262f + bob, 84f, 252f + bob)
            cubicTo(96f, 268f + bob, 112f, 258f + bob, 120f, 268f + bob)
            cubicTo(130f, 258f + bob, 146f, 268f + bob, 158f, 252f + bob)
            cubicTo(172f, 262f + bob, 184f, 250f + bob, 200f, 258f + bob)
            cubicTo(188f, 208f + bob, 192f, 150f + bob, 182f, 96f + bob)
            close()
        }
        canvas.drawPath(p, hairDark)
        // 发丝高光
        val shine = Path().apply {
            moveTo(68f, 130f + bob)
            cubicTo(62f, 176f + bob, 64f, 216f + bob, 58f, 244f + bob)
        }
        canvas.drawPath(shine, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5C8CE0")
            style = Paint.Style.STROKE
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
            alpha = 150
        })
    }

    private fun drawBody(canvas: Canvas, bob: Float) {
        // 连衣裙
        val skirt = Path().apply {
            moveTo(88f, 214f + bob)
            lineTo(152f, 214f + bob)
            lineTo(170f, 288f + bob)
            lineTo(70f, 288f + bob)
            close()
        }
        canvas.drawPath(skirt, dress)
        // 白围裙
        val apronRect = RectF(96f, 236f + bob, 144f, 286f + bob)
        canvas.drawRoundRect(apronRect, 14f, 14f, apron)
        // 围裙上的小鲸鱼符号
        val whale = Path().apply {
            moveTo(112f, 262f + bob)
            cubicTo(116f, 256f + bob, 126f, 256f + bob, 128f, 262f + bob)
            lineTo(134f, 258f + bob)
            cubicTo(132f, 264f + bob, 132f, 268f + bob, 134f, 272f + bob)
            lineTo(126f, 268f + bob)
            cubicTo(122f, 272f + bob, 114f, 270f + bob, 112f, 262f + bob)
            close()
        }
        canvas.drawPath(whale, irisDeep)
        // 胸口蝴蝶结
        val bowLeft = Path().apply {
            moveTo(120f, 216f + bob)
            lineTo(108f, 210f + bob)
            lineTo(108f, 222f + bob)
            close()
        }
        val bowRight = Path().apply {
            moveTo(120f, 216f + bob)
            lineTo(132f, 210f + bob)
            lineTo(132f, 222f + bob)
            close()
        }
        canvas.drawPath(bowLeft, hairMid)
        canvas.drawPath(bowRight, hairMid)
        canvas.drawCircle(120f, 216f + bob, 3.4f, irisDeep)
        // 泡泡袖
        canvas.drawCircle(88f, 222f + bob, 13f, lace)
        canvas.drawCircle(152f, 222f + bob, 13f, lace)
        // 手
        canvas.drawCircle(84f, 238f + bob, 7f, skin)
        canvas.drawCircle(156f, 238f + bob, 7f, skin)
        // 腿与鞋
        canvas.drawRoundRect(RectF(104f, 286f + bob, 114f, 306f + bob), 5f, 5f, dress)
        canvas.drawRoundRect(RectF(126f, 286f + bob, 136f, 306f + bob), 5f, 5f, dress)
        canvas.drawRoundRect(RectF(100f, 302f + bob, 116f, 312f + bob), 5f, 5f, tailPaint)
        canvas.drawRoundRect(RectF(124f, 302f + bob, 140f, 312f + bob), 5f, 5f, tailPaint)
    }

    // ---------- 头部 ----------

    private fun drawFinEars(canvas: Canvas, bob: Float) {
        val left = Path().apply {
            moveTo(64f, 118f + bob)
            cubicTo(40f, 122f + bob, 30f, 136f + bob, 34f, 152f + bob)
            cubicTo(44f, 140f + bob, 56f, 134f + bob, 68f, 134f + bob)
            close()
        }
        val right = Path().apply {
            moveTo(176f, 118f + bob)
            cubicTo(200f, 122f + bob, 210f, 136f + bob, 206f, 152f + bob)
            cubicTo(196f, 140f + bob, 184f, 134f + bob, 172f, 134f + bob)
            close()
        }
        canvas.drawPath(left, hairMid)
        canvas.drawPath(right, hairMid)
    }

    private fun drawFace(canvas: Canvas, bob: Float) {
        // 脸
        canvas.drawOval(RectF(70f, 74f + bob, 170f, 178f + bob), skin)
        // 腮红
        blush.alpha = 90
        canvas.drawOval(RectF(80f, 140f + bob, 100f, 152f + bob), blush)
        canvas.drawOval(RectF(140f, 140f + bob, 160f, 152f + bob), blush)
        blush.alpha = 255
    }

    private fun drawBangs(canvas: Canvas, bob: Float) {
        val bangs = Path().apply {
            moveTo(68f, 128f + bob)
            cubicTo(64f, 84f + bob, 90f, 62f + bob, 120f, 62f + bob)
            cubicTo(150f, 62f + bob, 176f, 84f + bob, 172f, 128f + bob)
            cubicTo(166f, 112f + bob, 156f, 104f + bob, 146f, 108f + bob)
            cubicTo(140f, 98f + bob, 130f, 96f + bob, 122f, 102f + bob)
            cubicTo(114f, 94f + bob, 102f, 96f + bob, 96f, 106f + bob)
            cubicTo(84f, 102f + bob, 74f, 112f + bob, 68f, 128f + bob)
            close()
        }
        canvas.drawPath(bangs, hairDark)
        // 呆毛
        val ahoge = Path().apply {
            moveTo(118f, 64f + bob)
            cubicTo(116f, 48f + bob, 128f, 42f + bob, 134f, 34f + bob)
            cubicTo(128f, 46f + bob, 124f, 54f + bob, 126f, 64f + bob)
        }
        canvas.drawPath(ahoge, lash)
    }

    private fun drawHeadband(canvas: Canvas, bob: Float) {
        // 白色蕾丝头纱：上缘弧线 + 下缘扇形齿
        val band = Path().apply {
            moveTo(62f, 104f + bob)
            cubicTo(66f, 62f + bob, 92f, 48f + bob, 120f, 48f + bob)
            cubicTo(148f, 48f + bob, 174f, 62f + bob, 178f, 104f + bob)
            var x = 176f
            while (x > 64f) {
                lineTo(x - 6f, 96f + bob)
                lineTo(x - 12f, 104f + bob)
                x -= 12f
            }
            close()
        }
        canvas.drawPath(band, lace)
        // 两侧蝴蝶结
        for (cx in listOf(66f, 174f)) {
            val b = Path().apply {
                moveTo(cx, 96f + bob)
                lineTo(cx - 12f, 88f + bob)
                lineTo(cx - 12f, 104f + bob)
                close()
            }
            val b2 = Path().apply {
                moveTo(cx, 96f + bob)
                lineTo(cx + 12f, 88f + bob)
                lineTo(cx + 12f, 104f + bob)
                close()
            }
            canvas.drawPath(b, hairMid)
            canvas.drawPath(b2, hairMid)
            canvas.drawCircle(cx, 96f + bob, 3.2f, irisDeep)
        }
    }

    private fun drawEyes(canvas: Canvas, bob: Float, blinking: Boolean) {
        val happy = expression == "happy"
        val sleepy = expression == "sleepy"
        val sad = expression == "sad"

        val eyeY = 134f + bob
        val rx = 15f
        val ry = if (happy) 9f else 16f

        if (blinking || sleepy) {
            canvas.drawPath(arcLash(90f, eyeY), lash)
            canvas.drawPath(arcLash(134f, eyeY), lash)
            return
        }

        for (cx in listOf(98f, 142f)) {
            canvas.drawOval(RectF(cx - rx, eyeY - ry, cx + rx, eyeY + ry), eyeWhite)
            canvas.drawOval(RectF(cx - 11f, eyeY - ry + 3f, cx + 11f, eyeY + ry - 2f), iris)
            canvas.drawOval(RectF(cx - 6f, eyeY - 7f, cx + 4f, eyeY + 7f), irisDeep)
            canvas.drawCircle(cx - 5f, eyeY - 6f, 3.2f, eyeWhite)
            canvas.drawCircle(cx + 4f, eyeY + 5f, 1.6f, eyeWhite)
            // 上睫毛
            canvas.drawPath(arcLash(cx, eyeY - ry + 2f), lash)
        }
        if (sad) {
            canvas.drawLine(88f, eyeY - 20f, 108f, eyeY - 16f, lash)
            canvas.drawLine(132f, eyeY - 16f, 152f, eyeY - 20f, lash)
        }
    }

    private fun arcLash(cx: Float, y: Float): Path = Path().apply {
        moveTo(cx - 14f, y)
        quadTo(cx, y - 7f, cx + 14f, y)
    }

    private fun drawMouth(canvas: Canvas, bob: Float, talking: Boolean) {
        val y = 156f + bob
        when {
            talking -> {
                val open = 4f + abs(sin(phase * 6f)) * 5f
                canvas.drawOval(RectF(114f, y, 126f, y + open), line)
            }
            expression == "happy" -> {
                canvas.drawPath(Path().apply {
                    moveTo(110f, y)
                    quadTo(120f, y + 8f, 130f, y)
                }, line)
            }
            expression == "sad" -> {
                canvas.drawPath(Path().apply {
                    moveTo(112f, y + 5f)
                    quadTo(120f, y - 2f, 128f, y + 5f)
                }, line)
            }
            else -> canvas.drawLine(116f, y + 1f, 124f, y + 1f, line)
        }
    }

    // ---------- 气泡 ----------

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, top: Float) {
        val maxWidth = 150f
        val lines = wrap(text, maxWidth - 18f)
        val lineHeight = textPaint.textSize * 1.35f
        val height = lines.size * lineHeight + 14f
        val width = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 18f)
        val left = (W - width) / 2f
        val box = RectF(left, top, left + width, top + height)
        canvas.drawRoundRect(box, 9f, 9f, bubblePaint)
        var y = box.top + 10f + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 9f, y, textPaint)
            y += lineHeight
        }
        val tail = Path().apply {
            moveTo(cx - 6f, box.bottom)
            lineTo(cx, box.bottom + 8f)
            lineTo(cx + 6f, box.bottom)
            close()
        }
        canvas.drawPath(tail, bubblePaint)
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
