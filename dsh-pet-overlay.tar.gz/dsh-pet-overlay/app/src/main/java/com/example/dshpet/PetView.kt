package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * 真正的鲸鱼娘：素材来自 dsh-pet 插件的 PNG（透明背景），按状态切换形象。
 * pose 取值：idle / happy（在干活）/ sleep / offline（连不上 DSH）
 */
class PetView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private var phase = 0f

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    var pose: String = "idle"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    private val cache = HashMap<String, Bitmap?>()

    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 13f * density
    }

    private fun art(): Bitmap? {
        if (cache.containsKey(pose)) return cache[pose]
        val loaded = runCatching {
            context.assets.open("pet/$pose.png").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        cache[pose] = loaded
        return loaded
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bob = sin(phase) * 5f * density
        val bmp = art()

        if (bmp != null) {
            val availableWidth = width - 12f * density
            val availableHeight = height - 72f * density
            val scale = minOf(availableWidth / bmp.width, availableHeight / bmp.height)
            val drawWidth = bmp.width * scale
            val drawHeight = bmp.height * scale
            val left = (width - drawWidth) / 2f
            val top = height - drawHeight + bob
            canvas.drawBitmap(bmp, null, RectF(left, top, left + drawWidth, top + drawHeight), null)
        }

        speech?.let { drawBubble(canvas, it, width / 2f, 66f * density) }
    }

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, bottom: Float) {
        val maxWidth = 168f * density
        val lines = wrap(text, maxWidth - 20f * density)
        val lineHeight = textPaint.textSize * 1.35f
        val height = lines.size * lineHeight + 16f * density
        val width = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 20f * density)
        val rect = RectF(cx - width / 2f, bottom - height, cx + width / 2f, bottom)
        canvas.drawRoundRect(rect, 12f * density, 12f * density, bubblePaint)
        var y = rect.top + 12f * density + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, rect.left + 10f * density, y, textPaint)
            y += lineHeight
        }
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 4) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
