package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * 一只用 Canvas 画出来的胖鲸鱼，不依赖任何图片资源。
 * 说话内容用头顶的气泡展示；工作时摆尾更快。
 */
class PetView(context: Context) : View(context) {

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    var working: Boolean = false
        set(value) {
            field = value
            animate().cancel()
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private var phase = 0f

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3B7DE0") }
    private val bellyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DCE9FF") }
    private val finPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFBE5C") }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#12233D") }
    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF9DBB") }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 13f * density
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bob = sin(phase) * 4f * density
        val speed = if (working) 2f else 1f
        val sway = sin(phase * 1.6f * speed) * 6f * density

        val cx = width / 2f
        val cy = height * 0.62f + bob

        // 尾巴
        val tail = Path().apply {
            moveTo(cx + 26f * density, cy)
            lineTo(cx + 54f * density, cy - 22f * density + sway)
            lineTo(cx + 54f * density, cy + 22f * density + sway)
            close()
        }
        canvas.drawPath(tail, finPaint)

        // 身体
        val body = RectF(cx - 40f * density, cy - 30f * density, cx + 40f * density, cy + 30f * density)
        canvas.drawOval(body, bodyPaint)
        val belly = RectF(cx - 26f * density, cy + 2f * density, cx + 22f * density, cy + 28f * density)
        canvas.drawOval(belly, bellyPaint)

        // 眼睛
        canvas.drawCircle(cx - 12f * density, cy - 6f * density, 5f * density, eyePaint)
        canvas.drawCircle(cx - 10f * density, cy - 8f * density, 1.6f * density, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })

        // 腮红
        canvas.drawOval(
            RectF(cx - 26f * density, cy + 2f * density, cx - 12f * density, cy + 12f * density),
            blushPaint
        )

        speech?.let { drawBubble(canvas, it, cx, cy - 44f * density) }
    }

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, top: Float) {
        val maxWidth = 180f * density
        val lines = wrap(text, maxWidth - 20f * density)
        val lineHeight = textPaint.textSize * 1.35f
        val height = lines.size * lineHeight + 16f * density
        val width = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 20f * density)
        val rect = RectF(cx - width / 2f, top - height, cx + width / 2f, top)
        canvas.drawRoundRect(rect, 12f * density, 12f * density, bubblePaint)
        var y = rect.top + 12f * density + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, rect.left + 10f * density, y, textPaint)
            y += lineHeight
        }
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 4) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
