package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * 鲸鱼娘（模型固定为原画抠图），表情与动作全部用代码实现：
 *
 *  - 动作：呼吸、浮动、摇头、发丝摆动的连续动画；一次性动作 跳/弹/旋/晃/倾/压扁
 *  - 表情：不换图，用符号表达情绪 —— 腮红、爱心、眼泪、汗滴、怒气、Zzz、感叹号、问号、音符
 */
class PetView(context: Context) : View(context) {

    private var phase = 0f
    private var talkUntil = 0L
    private var actionName = ""
    private var actionStartedAt = 0L
    private var nextIdleActionAt = System.currentTimeMillis() + 20_000
    private var nextIdleEmoteAt = System.currentTimeMillis() + 26_000

    private var emoteName: String? = null
    private var emoteAt = 0L

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val sprite: Bitmap? by lazy {
        runCatching {
            context.assets.open("pet/normal.png").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }

    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F7FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 26f
    }
    private val emotePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        showEmote("note", 1200)
    }

    fun play(action: String) {
        actionName = action
        actionStartedAt = System.currentTimeMillis()
        invalidate()
    }

    /** 显示一个情绪符号：blush / heart / tear / sweat / anger / zzz / exclaim / question / note */
    fun showEmote(name: String, durationMs: Long = 2000) {
        emoteName = name
        emoteAt = System.currentTimeMillis()
        emoteUntil = emoteAt + durationMs
        invalidate()
    }

    private var emoteUntil = 0L

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        val bob = sin(phase) * height * 0.012f
        val breathe = 1f + sin(phase * 2f) * 0.014f
        val sway = sin(phase * 0.55f) * 1.6f

        // 自娱自乐：动作与情绪分开计时
        if (now >= nextIdleActionAt) {
            val pool = listOf("jump", "nod", "wave", "bounce", "lean", "squash", "shake", "spin")
            play(pool[(Math.random() * pool.size).toInt()])
            nextIdleActionAt = now + 18_000 + (Math.random() * 12_000).toLong()
        }
        if (now >= nextIdleEmoteAt) {
            val pool = listOf("blush", "heart", "note", "zzz", "question", "exclaim", "sweat")
            showEmote(pool[(Math.random() * pool.size).toInt()])
            nextIdleEmoteAt = now + 26_000 + (Math.random() * 16_000).toLong()
        }

        var dx = 0f
        var dy = 0f
        var rotation = 0f
        var squash = 1f
        if (actionStartedAt > 0L) {
            val duration = when (actionName) {
                "jump" -> 620f
                "shake" -> 520f
                "nod" -> 680f
                "wave" -> 900f
                "spin" -> 1000f
                "bounce" -> 820f
                "lean" -> 640f
                "squash" -> 540f
                else -> 0f
            }
            if (duration > 0f) {
                val t = (now - actionStartedAt) / duration
                if (t in 0f..1f) {
                    val p = PI.toFloat()
                    // 缓动：先快后慢
                    val e = sin(p * t / 2)
                    when (actionName) {
                        "jump" -> dy = -height * 0.10f * sin(p * t)
                        "shake" -> dx = width * 0.03f * sin(t * p * 6) * (1 - t)
                        "nod" -> rotation = 6f * sin(t * p * 2) * (1 - t)
                        "wave" -> {
                            rotation = 9f * sin(t * p * 3) * (1 - t)
                            dx = width * 0.02f * sin(t * p * 2) * (1 - t)
                        }
                        "spin" -> rotation = 360f * e
                        "bounce" -> dy = -height * 0.05f * abs(sin(t * p * 2))
                        "lean" -> rotation = 8f * sin(t * p) * (1 - t)
                        "squash" -> squash = 1f - 0.07f * sin(p * t)
                    }
                }
            }
        }

        val bitmap = sprite
        if (bitmap != null) {
            val availableHeight = height * 0.86f
            val scale = minOf(width / bitmap.width.toFloat(), availableHeight / bitmap.height.toFloat()) * breathe
            val drawWidth = bitmap.width * scale
            val drawHeight = bitmap.height * scale
            val left = (width - drawWidth) / 2f + dx
            val top = height - drawHeight + bob + dy
            canvas.save()
            canvas.rotate(sway + rotation, width / 2f, top + drawHeight * 0.62f)
            canvas.scale(1f / squash, squash, width / 2f, top + drawHeight)
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + drawWidth, top + drawHeight), null)
            canvas.restore()
            drawEmote(canvas, now, left, top, drawWidth, drawHeight)
        }

        speech?.let { drawBubble(canvas, it) }
    }

    /** 情绪符号：画在头部两侧，带淡出。 */
    private fun drawEmote(canvas: Canvas, now: Long, left: Float, top: Float, w: Float, h: Float) {
        val name = emoteName ?: return
        if (now >= emoteUntil) return
        val life = (emoteUntil - now).toFloat() / 2000f
        val alpha = (life * 255).toInt().coerceIn(0, 255)
        val cx = left + w * 0.78f
        val cy = top + h * 0.24f
        val r = w * 0.07f

        when (name) {
            "blush" -> {
                emotePaint.color = Color.argb(alpha / 2, 255, 120, 150)
                canvas.drawCircle(left + w * 0.34f, top + h * 0.44f, w * 0.09f, emotePaint)
                canvas.drawCircle(left + w * 0.66f, top + h * 0.44f, w * 0.09f, emotePaint)
            }
            "heart" -> {
                emotePaint.color = Color.argb(alpha, 255, 90, 130)
                val path = Path()
                path.moveTo(cx, cy + r * 1.4f)
                path.cubicTo(cx - r * 3f, cy - r, cx - r * 1.2f, cy - r * 2.4f, cx, cy - r * 0.6f)
                path.cubicTo(cx + r * 1.2f, cy - r * 2.4f, cx + r * 3f, cy - r, cx, cy + r * 1.4f)
                canvas.drawPath(path, emotePaint)
            }
            "tear" -> {
                emotePaint.color = Color.argb(alpha, 90, 170, 255)
                val x = left + w * 0.36f
                val y = top + h * 0.42f
                val path = Path()
                path.moveTo(x, y - r * 1.6f)
                path.cubicTo(x + r, y - r * 0.2f, x + r, y + r, x, y + r * 1.2f)
                path.cubicTo(x - r, y + r, x - r, y - r * 0.2f, x, y - r * 1.6f)
                canvas.drawPath(path, emotePaint)
            }
            "sweat" -> {
                emotePaint.color = Color.argb(alpha, 130, 200, 255)
                val x = left + w * 0.16f
                val y = top + h * 0.26f
                canvas.drawCircle(x, y, r * 0.9f, emotePaint)
            }
            "anger" -> {
                emotePaint.color = Color.argb(alpha, 235, 70, 70)
                val x = left + w * 0.8f
                val y = top + h * 0.18f
                canvas.drawLine(x - r, y - r, x + r, y + r, emotePaint)
                canvas.drawLine(x - r, y + r, x + r, y - r, emotePaint)
            }
            "zzz" -> {
                emotePaint.color = Color.argb(alpha, 120, 150, 220)
                emotePaint.textSize = w * 0.13f
                canvas.drawText("z", cx, cy, emotePaint)
                emotePaint.textSize = w * 0.10f
                canvas.drawText("z", cx + r * 2.2f, cy - r * 2f, emotePaint)
            }
            "exclaim" -> {
                emotePaint.color = Color.argb(alpha, 255, 170, 60)
                emotePaint.textSize = w * 0.18f
                canvas.drawText("!", cx, cy + r, emotePaint)
            }
            "question" -> {
                emotePaint.color = Color.argb(alpha, 120, 180, 255)
                emotePaint.textSize = w * 0.16f
                canvas.drawText("?", cx, cy + r, emotePaint)
            }
            "note" -> {
                emotePaint.color = Color.argb(alpha, 140, 120, 220)
                emotePaint.textSize = w * 0.14f
                canvas.drawText("♪", cx, cy, emotePaint)
            }
        }
    }

    private fun drawBubble(canvas: Canvas, text: String) {
        val maxWidth = width * 0.94f
        val lines = wrap(text, maxWidth - 24f)
        val lineHeight = textPaint.textSize * 1.35f
        val heightBox = lines.size * lineHeight + 20f
        val boxWidth = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 24f)
        val left = (width - boxWidth) / 2f
        val box = RectF(left, 0f, left + boxWidth, heightBox)
        canvas.drawRoundRect(box, 14f, 14f, bubble)
        var y = box.top + 12f + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 12f, y, textPaint)
            y += lineHeight
        }
        canvas.drawPath(Path().apply {
            moveTo(width / 2f - 8f, box.bottom)
            lineTo(width / 2f, box.bottom + 10f)
            lineTo(width / 2f + 8f, box.bottom)
            close()
        }, bubble)
    }

    private fun wrap(text: String, maxWidth: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > maxWidth) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
