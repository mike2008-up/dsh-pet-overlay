package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * 纯矢量 Q 版鲸鱼娘（不使用图片）。
 *
 * 层次（从后到前）：鲸尾 → 后发 → 侧发 → 身体 → 脸 → 刘海 → 蕾丝头纱 → 五官
 * 坐标系 240×320，整体缩放。
 */
class PetView(context: Context) : View(context) {

    private companion object {
        const val W = 240f
        const val H = 320f
    }

    private var phase = 0f
    private var blinkUntil = 0L
    private var nextBlinkAt = System.currentTimeMillis() + 2600
    private var talkUntil = 0L

    var expression: String = "normal"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3F6CC4") }
    private val hairDeep = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2C4E96") }
    private val hairShine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#6F9BEA") }
    private val skin = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFE2CF") }
    private val dress = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#20355F") }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FBFDFF") }
    private val tail = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A5187") }
    private val eyeWhite = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val iris = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2F74D6") }
    private val irisDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16305C") }
    private val lash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1B2A47")
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val mouth = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C4635F")
        style = Paint.Style.STROKE
        strokeWidth = 2.6f
        strokeCap = Paint.Cap.ROUND
    }
    private val blush = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF9DBB") }
    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5FFFFFF") }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 12f
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3400
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            maybeBlink()
            invalidate()
        }
        start()
    }

    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        invalidate()
    }

    private fun maybeBlink() {
        val now = System.currentTimeMillis()
        if (now >= nextBlinkAt) {
            blinkUntil = now + 130
            nextBlinkAt = now + 2500 + (Math.random() * 2500).toLong()
        }
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(width / W, height / H)

        val bob = sin(phase) * 3f
        val now = System.currentTimeMillis()

        drawTail(canvas, bob)
        drawBackHair(canvas, bob)
        drawSideHair(canvas, bob)
        drawBody(canvas, bob)
        canvas.save()
        canvas.rotate(sin(phase * 0.8f) * 1.2f, 120f, 160f)
        drawFace(canvas, bob)
        drawBangs(canvas, bob)
        drawHeadband(canvas, bob)
        drawEyes(canvas, bob, now < blinkUntil)
        drawMouth(canvas, bob, now < talkUntil)
        canvas.restore()

        speech?.let { drawBubble(canvas, it, 120f, 8f) }
        canvas.restore()
    }

    // ---------- 后面 ----------

    private fun drawTail(canvas: Canvas, bob: Float) {
        val sway = sin(phase * 1.5f) * 5f
        val p = Path().apply {
            moveTo(148f, 240f + bob)
            cubicTo(176f, 228f + bob + sway, 198f, 218f + bob + sway, 212f, 212f + bob + sway)
            cubicTo(204f, 232f + bob + sway, 204f, 252f + bob + sway, 212f, 270f + bob + sway)
            cubicTo(190f, 260f + bob + sway, 166f, 252f + bob, 148f, 240f + bob)
            close()
        }
        canvas.drawPath(p, tail)
    }

    private fun drawBackHair(canvas: Canvas, bob: Float) {
        // 头的轮廓发蓬
        canvas.drawOval(RectF(66f, 58f + bob, 174f, 176f + bob), hairDeep)
    }

    private fun drawSideHair(canvas: Canvas, bob: Float) {
        // 两条长发：从耳侧垂到腰部，末端圆润
        for (left in listOf(true, false)) {
            val x = if (left) 62f else 178f
            val sway = sin(phase + if (left) 0f else 1.2f) * 2.5f
            val p = Path().apply {
                moveTo(x - 13f, 120f + bob)
                cubicTo(x - 18f + sway, 170f + bob, x - 16f + sway, 210f + bob, x - 10f + sway, 244f + bob)
                cubicTo(x - 2f + sway, 252f + bob, x + 6f + sway, 252f + bob, x + 12f + sway, 244f + bob)
                cubicTo(x + 14f, 210f + bob, x + 15f, 170f + bob, x + 13f, 120f + bob)
                close()
            }
            canvas.drawPath(p, hair)
        }
        // 发丝高光
        val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#7AA6EE")
            style = Paint.Style.STROKE
            strokeWidth = 4f
            strokeCap = Paint.Cap.ROUND
            alpha = 170
        }
        canvas.drawPath(Path().apply {
            moveTo(74f, 130f + bob)
            cubicTo(70f, 168f + bob, 72f, 200f + bob, 76f, 226f + bob)
        }, shine)
    }

    // ---------- 身体 ----------

    private fun drawBody(canvas: Canvas, bob: Float) {
        // 裙子（上窄下宽）
        val skirt = Path().apply {
            moveTo(96f, 168f + bob)
            lineTo(144f, 168f + bob)
            lineTo(166f, 248f + bob)
            cubicTo(140f, 258f + bob, 100f, 258f + bob, 74f, 248f + bob)
            close()
        }
        canvas.drawPath(skirt, dress)
        // 白色围裙
        canvas.drawRoundRect(RectF(100f, 190f + bob, 140f, 244f + bob), 12f, 12f, white)
        // 围裙上的小鲸鱼
        val whale = Path().apply {
            moveTo(112f, 224f + bob)
            cubicTo(113f, 216f + bob, 127f, 216f + bob, 128f, 224f + bob)
            lineTo(134f, 219f + bob)
            cubicTo(132f, 226f + bob, 132f, 232f + bob, 134f, 238f + bob)
            lineTo(126f, 232f + bob)
            cubicTo(121f, 236f + bob, 113f, 232f + bob, 112f, 224f + bob)
            close()
        }
        canvas.drawPath(whale, irisDark)
        // 胸口领结
        val bowL = Path().apply {
            moveTo(120f, 170f + bob)
            lineTo(110f, 164f + bob)
            lineTo(110f, 176f + bob)
            close()
        }
        val bowR = Path().apply {
            moveTo(120f, 170f + bob)
            lineTo(130f, 164f + bob)
            lineTo(130f, 176f + bob)
            close()
        }
        canvas.drawPath(bowL, hair)
        canvas.drawPath(bowR, hair)
        canvas.drawCircle(120f, 170f + bob, 3f, irisDark)
        // 泡泡袖与手
        canvas.drawCircle(90f, 180f + bob, 12f, white)
        canvas.drawCircle(150f, 180f + bob, 12f, white)
        canvas.drawCircle(86f, 196f + bob, 6.5f, skin)
        canvas.drawCircle(154f, 196f + bob, 6.5f, skin)
        // 腿与鞋
        canvas.drawRoundRect(RectF(106f, 248f + bob, 116f, 270f + bob), 5f, 5f, dress)
        canvas.drawRoundRect(RectF(124f, 248f + bob, 134f, 270f + bob), 5f, 5f, dress)
        canvas.drawRoundRect(RectF(102f, 266f + bob, 118f, 278f + bob), 5f, 5f, tail)
        canvas.drawRoundRect(RectF(122f, 266f + bob, 138f, 278f + bob), 5f, 5f, tail)
    }

    // ---------- 头部 ----------

    private fun drawFace(canvas: Canvas, bob: Float) {
        canvas.drawOval(RectF(76f, 70f + bob, 164f, 158f + bob), skin)
        blush.alpha = 95
        canvas.drawOval(RectF(84f, 126f + bob, 100f, 136f + bob), blush)
        canvas.drawOval(RectF(140f, 126f + bob, 156f, 136f + bob), blush)
        blush.alpha = 255
    }

    private fun drawBangs(canvas: Canvas, bob: Float) {
        val p = Path().apply {
            moveTo(76f, 122f + bob)
            cubicTo(74f, 86f + bob, 94f, 66f + bob, 120f, 66f + bob)
            cubicTo(146f, 66f + bob, 166f, 86f + bob, 164f, 122f + bob)
            // 刘海下缘：中分两片
            cubicTo(158f, 104f + bob, 146f, 96f + bob, 134f, 100f + bob)
            cubicTo(128f, 92f + bob, 118f, 90f + bob, 110f, 98f + bob)
            cubicTo(98f, 94f + bob, 84f, 104f + bob, 76f, 122f + bob)
            close()
        }
        canvas.drawPath(p, hair)
        // 呆毛
        canvas.drawPath(Path().apply {
            moveTo(116f, 68f + bob)
            cubicTo(112f, 52f + bob, 124f, 44f + bob, 132f, 36f + bob)
            cubicTo(126f, 48f + bob, 122f, 56f + bob, 124f, 68f + bob)
        }, lash)
    }

    private fun drawHeadband(canvas: Canvas, bob: Float) {
        // 白色蕾丝带：一条粗弧 + 一排小半圆
        val band = Path().apply {
            moveTo(70f, 104f + bob)
            quadTo(120f, 48f + bob, 170f, 104f + bob)
        }
        canvas.drawPath(band, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFFFFF")
            style = Paint.Style.STROKE
            strokeWidth = 15f
            strokeCap = Paint.Cap.ROUND
        })
        // 蕾丝齿（小圆点沿弧线排列）
        for (i in 0..8) {
            val t = i / 8f
            val x = (1 - t) * (1 - t) * 70f + 2 * (1 - t) * t * 120f + t * t * 170f
            val y = (1 - t) * (1 - t) * (104f + bob) + 2 * (1 - t) * t * (48f + bob) + t * t * (104f + bob)
            canvas.drawCircle(x, y - 9f, 4.2f, white)
        }
        // 两侧蝴蝶结
        for (cx in listOf(70f, 170f)) {
            canvas.drawPath(Path().apply {
                moveTo(cx, 104f + bob)
                lineTo(cx - 12f, 96f + bob)
                lineTo(cx - 12f, 112f + bob)
                close()
            }, hair)
            canvas.drawPath(Path().apply {
                moveTo(cx, 104f + bob)
                lineTo(cx + 12f, 96f + bob)
                lineTo(cx + 12f, 112f + bob)
                close()
            }, hair)
            canvas.drawCircle(cx, 104f + bob, 3f, irisDark)
        }
    }

    private fun drawEyes(canvas: Canvas, bob: Float, blinking: Boolean) {
        val happy = expression == "happy"
        val sleepy = expression == "sleepy"
        val sad = expression == "sad"
        val y = 116f + bob
        val ry = if (happy) 8f else 14f

        if (blinking || sleepy) {
            canvas.drawPath(Path().apply {
                moveTo(90f, y)
                quadTo(102f, y - 6f, 114f, y)
            }, lash)
            canvas.drawPath(Path().apply {
                moveTo(126f, y)
                quadTo(138f, y - 6f, 150f, y)
            }, lash)
            return
        }

        for (cx in listOf(102f, 138f)) {
            canvas.drawOval(RectF(cx - 12f, y - ry, cx + 12f, y + ry), eyeWhite)
            canvas.drawOval(RectF(cx - 9f, y - ry + 2f, cx + 9f, y + ry - 2f), iris)
            canvas.drawOval(RectF(cx - 4.5f, y - 6f, cx + 3.5f, y + 6f), irisDark)
            canvas.drawCircle(cx - 4f, y - 5f, 2.8f, eyeWhite)
            canvas.drawCircle(cx + 3.5f, y + 4.5f, 1.4f, eyeWhite)
            canvas.drawPath(Path().apply {
                moveTo(cx - 12f, y - ry + 3f)
                quadTo(cx, y - ry - 4f, cx + 12f, y - ry + 3f)
            }, lash)
        }

        if (sad) {
            canvas.drawLine(92f, y - 19f, 112f, y - 15f, lash)
            canvas.drawLine(128f, y - 15f, 148f, y - 19f, lash)
        }
    }

    private fun drawMouth(canvas: Canvas, bob: Float, talking: Boolean) {
        val y = 138f + bob
        when {
            talking -> {
                val open = 3.5f + abs(sin(phase * 6f)) * 4.5f
                canvas.drawOval(RectF(115f, y, 125f, y + open), mouth)
            }
            expression == "happy" -> canvas.drawPath(Path().apply {
                moveTo(111f, y)
                quadTo(120f, y + 7f, 129f, y)
            }, mouth)
            expression == "sad" -> canvas.drawPath(Path().apply {
                moveTo(113f, y + 4f)
                quadTo(120f, y - 2f, 127f, y + 4f)
            }, mouth)
            else -> canvas.drawLine(116f, y + 1f, 124f, y + 1f, mouth)
        }
    }

    // ---------- 气泡 ----------

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, top: Float) {
        val maxWidth = 148f
        val lines = wrap(text, maxWidth - 18f)
        val lineHeight = this.text.textSize * 1.35f
        val height = lines.size * lineHeight + 13f
        val width = minOf(maxWidth, lines.maxOf { this.text.measureText(it) } + 18f)
        val left = (W - width) / 2f
        val box = RectF(left, top, left + width, top + height)
        canvas.drawRoundRect(box, 9f, 9f, bubble)
        var y = box.top + 9f + this.text.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 9f, y, this.text)
            y += lineHeight
        }
        canvas.drawPath(Path().apply {
            moveTo(cx - 6f, box.bottom)
            lineTo(cx, box.bottom + 8f)
            lineTo(cx + 6f, box.bottom)
            close()
        }, bubble)
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (this.text.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
