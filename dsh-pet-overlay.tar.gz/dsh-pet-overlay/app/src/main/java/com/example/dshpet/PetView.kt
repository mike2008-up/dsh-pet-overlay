package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * 纯代码画的 2D 鲸鱼娘（不依赖任何图片素材）。
 *
 * 动画：呼吸起伏、眨眼、尾巴摆动、说话时动嘴。
 * 表情：normal / happy / sleepy / sad，由外部设置。
 * 坐标系固定按 240×300 设计，再整体缩放到控件大小，所以尺寸随窗口变。
 */
class PetView(context: Context) : View(context) {

    private companion object {
        const val DESIGN_W = 240f
        const val DESIGN_H = 300f
    }

    private val density = resources.displayMetrics.density
    private var phase = 0f
    private var blinkUntil = 0L
    private var nextBlinkAt = System.currentTimeMillis() + 2600
    private var talkUntil = 0L

    /** 表情：normal / happy / sleepy / sad */
    var expression: String = "normal"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val hairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3E6FD0") }
    private val hairLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5B8EE8") }
    private val skinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFE3D2") }
    private val dressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2B4C86") }
    private val dressLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F4F7FF") }
    private val tailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4C82DC") }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#22305A") }
    private val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF9DBB") }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C9736F")
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        strokeCap = Paint.Cap.ROUND
    }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 12f
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            maybeBlink()
            invalidate()
        }
        start()
    }

    /** 说一句话：动几秒嘴。 */
    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        invalidate()
    }

    private fun maybeBlink() {
        val now = System.currentTimeMillis()
        if (now >= nextBlinkAt) {
            blinkUntil = now + 130
            nextBlinkAt = now + 2400 + (Math.random() * 2600).toLong()
        }
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width / DESIGN_W
        val sy = height / DESIGN_H
        canvas.save()
        canvas.scale(sx, sy)

        val bob = sin(phase) * 4f
        val breathe = 1f + sin(phase * 2f) * 0.012f
        val now = System.currentTimeMillis()
        val blinking = now < blinkUntil
        val talking = now < talkUntil

        drawTail(canvas, bob)
        drawBody(canvas, bob)
        canvas.save()
        canvas.translate(120f, 130f + bob)
        canvas.scale(1f, breathe)
        canvas.translate(-120f, -130f)
        drawHead(canvas, blinking, talking)
        canvas.restore()

        speech?.let { drawBubble(canvas, it, 120f, 44f) }
        canvas.restore()
    }

    private fun drawTail(canvas: Canvas, bob: Float) {
        val sway = sin(phase * 1.8f) * 7f
        val path = Path().apply {
            moveTo(158f, 236f + bob)
            cubicTo(186f, 216f + bob + sway, 206f, 208f + bob + sway, 218f, 200f + bob + sway)
            cubicTo(210f, 220f + bob + sway, 210f, 246f + bob + sway, 218f, 266f + bob + sway)
            cubicTo(198f, 254f + bob + sway, 176f, 246f + bob, 158f, 236f + bob)
            close()
        }
        canvas.drawPath(path, tailPaint)
    }

    private fun drawBody(canvas: Canvas, bob: Float) {
        // 裙子
        val dress = Path().apply {
            moveTo(92f, 198f + bob)
            lineTo(148f, 198f + bob)
            lineTo(164f, 268f + bob)
            lineTo(76f, 268f + bob)
            close()
        }
        canvas.drawPath(dress, dressPaint)
        // 围裙
        val apron = RectF(104f, 214f + bob, 136f, 262f + bob)
        canvas.drawRoundRect(apron, 10f, 10f, dressLightPaint)
        // 水手领
        val collar = Path().apply {
            moveTo(96f, 196f + bob)
            lineTo(120f, 214f + bob)
            lineTo(144f, 196f + bob)
            lineTo(134f, 192f + bob)
            lineTo(120f, 204f + bob)
            lineTo(106f, 192f + bob)
            close()
        }
        canvas.drawPath(collar, dressPaint)
        // 手臂
        canvas.drawOval(RectF(72f, 206f + bob, 88f, 236f + bob), dressLightPaint)
        canvas.drawOval(RectF(152f, 206f + bob, 168f, 236f + bob), dressLightPaint)
    }

    private fun drawHead(canvas: Canvas, blinking: Boolean, talking: Boolean) {
        // 后面的长发
        canvas.drawOval(RectF(44f, 52f, 196f, 210f), hairPaint)
        // 侧发（鲸鳍形状）
        canvas.drawOval(RectF(28f, 120f, 70f, 214f), hairPaint)
        canvas.drawOval(RectF(170f, 120f, 212f, 214f), hairPaint)
        // 脸
        canvas.drawOval(RectF(72f, 78f, 168f, 182f), skinPaint)
        // 刘海
        val bang = Path().apply {
            moveTo(72f, 120f)
            cubicTo(70f, 78f, 96f, 58f, 120f, 58f)
            cubicTo(144f, 58f, 170f, 78f, 168f, 120f)
            cubicTo(160f, 100f, 146f, 94f, 136f, 100f)
            cubicTo(126f, 90f, 112f, 90f, 104f, 100f)
            cubicTo(92f, 94f, 80f, 100f, 72f, 120f)
            close()
        }
        canvas.drawPath(bang, hairPaint)
        canvas.drawOval(RectF(58f, 74f, 96f, 116f), hairLightPaint)

        val happy = expression == "happy"
        val sleepy = expression == "sleepy"
        val sad = expression == "sad"

        // 眼睛
        val eyeTop = if (happy) 132f else 134f
        val eyeH = if (happy) 12f else 18f
        if (blinking || sleepy) {
            canvas.drawLine(90f, 142f, 108f, 142f, mouthPaint)
            canvas.drawLine(132f, 142f, 150f, 142f, mouthPaint)
        } else {
            canvas.drawOval(RectF(90f, eyeTop - eyeH / 2, 108f, eyeTop + eyeH / 2), whitePaint)
            canvas.drawOval(RectF(132f, eyeTop - eyeH / 2, 150f, eyeTop + eyeH / 2), whitePaint)
            canvas.drawOval(RectF(95f, eyeTop - 6f, 105f, eyeTop + 6f), eyePaint)
            canvas.drawOval(RectF(137f, eyeTop - 6f, 147f, eyeTop + 6f), eyePaint)
            canvas.drawCircle(97f, eyeTop - 3f, 1.8f, whitePaint)
            canvas.drawCircle(139f, eyeTop - 3f, 1.8f, whitePaint)
        }

        // 腮红
        blushPaint.alpha = if (happy) 130 else 80
        canvas.drawOval(RectF(82f, 152f, 100f, 162f), blushPaint)
        canvas.drawOval(RectF(140f, 152f, 158f, 162f), blushPaint)
        blushPaint.alpha = 255

        // 嘴
        if (talking) {
            val open = 3f + abs(sin(phase * 6f)) * 5f
            canvas.drawOval(RectF(114f, 158f, 126f, 158f + open), mouthPaint)
        } else if (happy) {
            val smile = Path().apply {
                moveTo(110f, 158f)
                quadTo(120f, 168f, 130f, 158f)
            }
            canvas.drawPath(smile, mouthPaint)
        } else if (sad) {
            val frown = Path().apply {
                moveTo(112f, 164f)
                quadTo(120f, 157f, 128f, 164f)
            }
            canvas.drawPath(frown, mouthPaint)
        } else {
            canvas.drawLine(116f, 160f, 124f, 160f, mouthPaint)
        }
    }

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, bottom: Float) {
        val maxWidth = 150f
        val lines = wrap(text, maxWidth - 18f)
        val lineHeight = textPaint.textSize * 1.35f
        val height = lines.size * lineHeight + 14f
        val width = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 18f)
        val left = (DESIGN_W - width) / 2f
        val box = RectF(left, bottom, left + width, bottom + height)
        canvas.drawRoundRect(box, 9f, 9f, bubblePaint)
        var y = box.top + 10f + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 9f, y, textPaint)
            y += lineHeight
        }
        val tail = Path().apply {
            moveTo(cx - 6f, box.bottom)
            lineTo(cx, box.bottom + 8f)
            lineTo(cx + 6f, box.bottom)
            close()
        }
        canvas.drawPath(tail, bubblePaint)
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
