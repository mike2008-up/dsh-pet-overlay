package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.sin

/**
 * 真正的鲸鱼娘：素材来自 dsh-pet 插件的 PNG（透明背景），按状态切换形象。
 * pose 取值：idle / happy（在干活）/ sleep / offline（连不上 DSH）
 */
class PetView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private var phase = 0f

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    var pose: String = "idle"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    private val cache = HashMap<String, Bitmap?>()

    /** 表情名 → 打包后的文件名（memes.json 由构建脚本生成）。 */
    private val memes: Map<String, String> by lazy {
        runCatching {
            val text = context.assets.open("pet/memes.json").use { it.readBytes().toString(Charsets.UTF_8) }
            val json = JSONObject(text)
            json.keys().asSequence().associateWith { key -> json.getString(key) }
        }.getOrDefault(emptyMap())
    }

    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 13f * density
    }

    private fun art(): Bitmap? {
        if (cache.containsKey(pose)) return cache[pose]
        val candidates = buildList {
            memes[pose]?.let { add("pet/memes/$it") }
            add("pet/$pose.png")
            add("pet/idle.png")
        }
        var loaded: Bitmap? = null
        for (path in candidates) {
            loaded = runCatching {
                context.assets.open(path).use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (loaded != null) break
        }
        cache[pose] = loaded
        return loaded
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bob = sin(phase) * 8f * density
        val sway = sin(phase * 0.7f) * 2.5f
        val bmp = art()

        if (bmp != null) {
            val availableWidth = width - 12f * density
            val availableHeight = height - 72f * density
            val scale = minOf(availableWidth / bmp.width, availableHeight / bmp.height)
            val drawWidth = bmp.width * scale
            val drawHeight = bmp.height * scale
            val left = (width - drawWidth) / 2f
            val top = height - drawHeight + bob
            canvas.save()
            canvas.rotate(sway, width / 2f, top + drawHeight)
            canvas.drawBitmap(bmp, null, RectF(left, top, left + drawWidth, top + drawHeight), null)
            canvas.restore()
        }

        speech?.let { drawBubble(canvas, it, width / 2f, 66f * density) }
    }

    private fun drawBubble(canvas: Canvas, text: String, cx: Float, bottom: Float) {
        val maxWidth = 168f * density
        val lines = wrap(text, maxWidth - 20f * density)
        val lineHeight = textPaint.textSize * 1.35f
        val height = lines.size * lineHeight + 16f * density
        val width = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 20f * density)
        val rect = RectF(cx - width / 2f, bottom - height, cx + width / 2f, bottom)
        canvas.drawRoundRect(rect, 12f * density, 12f * density, bubblePaint)
        var y = rect.top + 12f * density + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, rect.left + 10f * density, y, textPaint)
            y += lineHeight
        }
    }

    private fun wrap(text: String, width: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > width) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 4) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
