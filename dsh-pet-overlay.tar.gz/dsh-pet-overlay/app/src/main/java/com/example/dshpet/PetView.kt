package com.example.dshpet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * 鲸鱼娘精灵：使用抠掉白底的透明 PNG（normal / happy / sleep），
 * 叠加呼吸、上下浮动、说话时轻微放大；气泡显示台词。
 */
class PetView(context: Context) : View(context) {

    private var phase = 0f
    private var talkUntil = 0L

    var expression: String = "normal"
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    var speech: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private val cache = HashMap<String, Bitmap?>()

    private fun sprite(): Bitmap? {
        val key = when (expression) {
            "happy" -> "happy"
            "sleepy" -> "sleep"
            else -> "normal"
        }
        if (cache.containsKey(key)) return cache[key]
        val loaded = runCatching {
            context.assets.open("pet/$key.png").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        cache[key] = loaded
        return loaded
    }

    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F7FFFFFF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F3557")
        textSize = 26f
    }

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    fun speak() {
        talkUntil = System.currentTimeMillis() + 2400
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bob = sin(phase) * height * 0.012f
        val breathe = 1f + sin(phase * 2f) * 0.015f
        val talking = System.currentTimeMillis() < talkUntil
        val pulse = if (talking) 1f + sin(phase * 6f) * 0.02f else 1f

        val bitmap = sprite()
        if (bitmap != null) {
            val availableHeight = height * 0.86f
            val scale = minOf(width / bitmap.width.toFloat(), availableHeight / bitmap.height.toFloat()) * breathe * pulse
            val drawWidth = bitmap.width * scale
            val drawHeight = bitmap.height * scale
            val left = (width - drawWidth) / 2f
            val top = height - drawHeight + bob
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + drawWidth, top + drawHeight), null)
        }

        speech?.let { drawBubble(canvas, it) }
    }

    private fun drawBubble(canvas: Canvas, text: String) {
        val maxWidth = width * 0.94f
        val lines = wrap(text, maxWidth - 24f)
        val lineHeight = textPaint.textSize * 1.35f
        val heightBox = lines.size * lineHeight + 20f
        val boxWidth = minOf(maxWidth, lines.maxOf { textPaint.measureText(it) } + 24f)
        val left = (width - boxWidth) / 2f
        val box = RectF(left, 0f, left + boxWidth, heightBox)
        canvas.drawRoundRect(box, 14f, 14f, bubble)
        var y = box.top + 12f + textPaint.textSize
        for (line in lines) {
            canvas.drawText(line, box.left + 12f, y, textPaint)
            y += lineHeight
        }
        val tail = Path().apply {
            moveTo(width / 2f - 8f, box.bottom)
            lineTo(width / 2f, box.bottom + 10f)
            lineTo(width / 2f + 8f, box.bottom)
            close()
        }
        canvas.drawPath(tail, bubble)
    }

    private fun wrap(text: String, maxWidth: Float): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        for (ch in text) {
            current.append(ch)
            if (textPaint.measureText(current.toString()) > maxWidth) {
                current.deleteCharAt(current.length - 1)
                out.add(current.toString())
                current = StringBuilder().append(ch)
            }
            if (out.size >= 3) break
        }
        if (current.isNotEmpty()) out.add(current.toString())
        return out
    }
}
