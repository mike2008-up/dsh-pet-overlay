# DSH 桌宠（Android 悬浮窗）

把 DSH 里那只宠物搬到**其他应用上面**的安卓工程骨架。

DSH 手机版里的宠物只是 WebView 内的浮层，出了那个界面就看不见。想要浮在微信、桌面之上，
必须由原生 App 用 `TYPE_APPLICATION_OVERLAY` 自己去画——这个工程就是干这个的。

## 它能做什么

- 一个前台服务 + 悬浮窗，宠物常驻在屏幕任意位置，可拖动
- 轮询 DSH 的 `/dsh-pet-7340/state`，读出「它想说的话」和「是否在干活」，驱动动画和气泡
- 用 Canvas 画的胖鲸鱼，不依赖任何图片素材

## 构建

1. 用 Android Studio 打开本目录（`dsh-pet-overlay`）
2. 首次打开会提示补 gradle wrapper，按提示生成即可（仓库里没带二进制 wrapper）
3. 直接 Run 到手机上

要求：compileSdk 34、minSdk 26、Kotlin 1.9.24、AGP 8.5.2。
依赖只有 AndroidX Core / AppCompat / kotlinx-coroutines。

## 使用顺序

1. **① 授予悬浮窗权限** —— 会跳到系统设置页，手动打开「显示在其他应用上层」
2. **② 连接 DSH** —— 粘贴 `dsh web` 启动时打印的完整地址
   （形如 `http://127.0.0.1:3080/?token=xxxx`）。
   App 会拿这个 token 去 `/connect` 换一颗 cookie，之后轮询都带它
3. **③ 启动桌宠** —— 然后就可以切到别的应用了

## 三个必须知道的限制

1. **token 只在当次 DSH 进程有效**。DSH 重启后 token 变了，要重新粘一次、重新连接
2. `/dsh-pet-7340/state` 只在**宠物插件宿主半侧已挂载**时可用。
   如果你刚装/刚更新过插件，需要先把 DSH 完整重启一次（见对话里的排查结论）
3. 第一次编译可能要在 Android Studio 里修一两处——这台机器没有 Android SDK，
   代码是**未经编译验证**的

## 目录

```
app/src/main/java/com/example/dshpet/
├── MainActivity.kt        授权、换 cookie、起停服务
├── PetOverlayService.kt   前台服务 + WindowManager 悬浮窗 + 轮询
├── PetView.kt             Canvas 画鲸鱼、气泡、拖动
├── DshClient.kt           token→cookie 交换、/state 解析
└── Prefs.kt               基地址 / cookie / 启动地址
```

## 想改成自己的形象

`PetView.onDraw()` 里全是用 `Canvas` 画的几何图形（身体、尾巴、眼睛、腮红），
换成 `drawBitmap` 贴图或者换颜色都很直接。动画在 `ValueAnimator` 里，改 `duration` 就行。

## 没有电脑？用 GitHub Actions 云构建

仓库里自带 `.github/workflows/build.yml`，推上去就自动编译。

1. 手机浏览器打开 github.com，登录后点右上角 `+` → **New repository**
2. 名字随意（例如 `dsh-pet-overlay`），选 **Public**，Create
3. 点 **Add file → Upload files**，上传 `dsh-pet-overlay.tar.gz`，Commit
4. 点 **Add file → Create new file**，文件名填 `.github/workflows/build.yml`，
   把仓库里同名文件的内容粘进去，Commit
5. 点顶部 **Actions** → 左侧 **Build APK** → 等 3～5 分钟
6. 打开那次运行，页面底部 **Artifacts** 下载 `dsh-pet-overlay-debug-apk`
7. 解压得到 `app-debug.apk`，安装（需要允许「安装未知来源应用」）

APK 是 debug 签名，只能自用，不能上架。
